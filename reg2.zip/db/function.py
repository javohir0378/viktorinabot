import asyncio
import random
from datetime import datetime
import mysql.connector
from aiogram.types import Message

from app import bot
from db.db import db_connection
from keyboards.reply.keyboards import create_balance_keyboard
from lang.translate import get_translation, get_user_language



async def send_question(user_id, test_uid, question_id):
    try:
        # Savol va media ma'lumotlarini olish
        connection = db_connection()
        cursor = connection.cursor()

        query = """
            SELECT question_text, addition, media_type 
            FROM questions 
            WHERE test_uid = %s AND question_id = %s
        """
        cursor.execute(query, (test_uid, question_id))
        question_row = cursor.fetchone()
        connection.close()

        if question_row:
            question_text, media, media_type = question_row

            # Javob variantlarini olish
            connection = db_connection()
            cursor = connection.cursor()

            query = """
                SELECT answer_text, is_correct 
                FROM answers 
                WHERE test_uid = %s AND question_id = %s 
                ORDER BY place_id
            """
            cursor.execute(query, (test_uid, question_id))
            answers = cursor.fetchall()
            connection.close()

            options = [(answer_text, is_correct) for answer_text, is_correct in answers]

            # Random variantlarni aralashtirish
            random_options = await check_random_options(test_uid)
            if random_options:
                random.shuffle(options)

            correct_option_index = next((index for index, (_, is_correct) in enumerate(options) if is_correct == 1), None)
            options_text = [answer_text for answer_text, _ in options]
            time_quiz = get_time_quiz_by_test_uid(test_uid)

            # Media bilan savolni foydalanuvchiga yuborish
            if media_type == "photo":
                await bot.send_photo(chat_id=user_id, photo=media, caption=question_text)
            elif media_type == "video":
                await bot.send_video(chat_id=user_id, video=media, caption=question_text)
            elif media_type == "document":
                await bot.send_document(chat_id=user_id, document=media, caption=question_text)
           # else:
                #await bot.send_message(chat_id=user_id, text=question_text)

            # Javob variantlarini yuborish
            poll_message = await bot.send_poll(
                chat_id=user_id,
                question=question_text,
                options=options_text,
                type="quiz",
                correct_option_id=correct_option_index,
                is_anonymous=False,
                open_period=time_quiz
            )

            # Poll ma'lumotlarini saqlash
            connection = db_connection()
            cursor = connection.cursor()

            query = """
                INSERT INTO polls (user_id, poll_id, question_id, test_uid, sent_time, correct_option_id)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (user_id, poll_message.poll.id, question_id, test_uid, datetime.now(), correct_option_index))
            connection.commit()
            connection.close()

            # time_quiz kutib, javobni tekshirish
            await asyncio.sleep(time_quiz)

            connection = db_connection()
            cursor = connection.cursor()

            query = """
                SELECT COUNT(*) 
                FROM user_answers 
                WHERE poll_id = %s AND user_id = %s
            """
            cursor.execute(query, (poll_message.poll.id, user_id))
            answer_count = cursor.fetchone()[0]
            connection.close()

            if answer_count == 0:
                # Agar javob bo'lmasa, skipped sifatida saqlash
                connection = db_connection()
                cursor = connection.cursor()

                query = """
                    INSERT INTO user_answers (user_id, poll_id, test_uid, question_id, answer_text, is_correct, skipped, answered_at, selected_option_index)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(query, (
                    user_id,
                    poll_message.poll.id,
                    test_uid,
                    question_id,
                    "Tashlab ketildi",  # Javob matni
                    0,                  # To'g'ri emas
                    1,                  # Skipped
                    None,               # Javob vaqti yo'q
                    None                # Variant tanlanmagan
                ))
                connection.commit()
                connection.close()

                # Keyingi savolni yuborish
                await send_next_question(user_id, test_uid)

        else:
            await bot.send_message(chat_id=user_id, text=f"Xato: Savol topilmadi. ID: {question_id}")

    except Exception as e:
        print(f"Xato: {e}")


async def check_random_options(test_uid):
    # Test UID bo'yicha random variantlarni tekshirish
    # False qaytaradi (agar randomizatsiya yo'q bo'lsa)
    return True


async def send_next_question(user_id, test_uid):
    """
    Keyingi savolni yuborish funksiyasi.
    """
    lang = await get_user_language(user_id)
    connection = None
    try:
        connection = db_connection()
        cursor = connection.cursor(dictionary=True)

        # Testdagi barcha savollarni olish
        query = "SELECT question_id FROM questions WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        all_questions = [row["question_id"] for row in cursor.fetchall()]

        if not all_questions:
            await bot.send_message(chat_id=user_id, text=get_translation(lang, "notfound_questions"))
            return

        # Foydalanuvchi javob bergan savollarni olish
        query = "SELECT question_id FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        sent_questions = [row["question_id"] for row in cursor.fetchall()]

        # Qolgan savollarni aniqlash
        remaining_questions = list(set(all_questions) - set(sent_questions))
        if not remaining_questions:
            # Foydalanuvchi barcha savollarga javob bergan bo‘lsa
            # To'g'ri javoblar sonini aniqlash
            query = """
                SELECT COUNT(*) AS correct_count 
                FROM polls 
                WHERE user_id = %s AND test_uid = %s AND is_correct = 1
            """
            cursor.execute(query, (user_id, test_uid))
            result = cursor.fetchone()
            correct_count = result["correct_count"] if result else 0

            if correct_count == len(all_questions):
                # Testda boshqa g'olib bor-yo'qligini tekshirish
                query = """
                    SELECT COUNT(*) AS winners_count 
                    FROM test_results 
                    WHERE test_uid = %s AND is_winner = 1
                """
                cursor.execute(query, (test_uid,))
                winner_count = cursor.fetchone()["winners_count"]

                if winner_count == 0:
                    # Foydalanuvchini g'olib deb e'lon qilish
                    query = "UPDATE users SET balance = balance + %s WHERE user_id = %s"
                    prize_coins = 100  # Mukofot miqdori (misol tariqasida 100 tanga)
                    cursor.execute(query, (prize_coins, user_id))
                    connection.commit()

                    # G'olibni `results` jadvaliga yozish
                    query = """
                        INSERT INTO test_results (user_id, test_uid, is_winner) 
                        VALUES (%s, %s, 1)
                    """
                    cursor.execute(query, (user_id, test_uid))
                    connection.commit()

                    await bot.send_message(
                        chat_id=user_id,
                        text=f"{get_translation(lang, "congratulations").format(prize_coins=prize_coins)}"
                    )
                else:
                    # Boshqa g'olib allaqachon mavjud
                    await bot.send_message(
                        chat_id=user_id,
                        text="Testda allaqachon g‘olib aniqlangan. Baribir qatnashganingiz uchun rahmat!"
                    )
            else:
                # Foydalanuvchi barcha savollarga to'g'ri javob bermagan
                await bot.send_message(chat_id=user_id, text="Testni yakunladingiz. Barcha savollarga to'g'ri javob bermadingiz.")
            return

        # Keyingi savolni yuborish
        random_question = await check_random_question(test_uid)
        question_id = random.choice(remaining_questions) if random_question else min(remaining_questions)

        await send_question(user_id, test_uid, question_id)

    except Exception as e:
        print(f"Xato: {e}")
    finally:
        if connection:
            connection.close()

def get_time_quiz_by_test_uid(test_uid):
    try:
        # Ulash
        connection = db_connection()
        cursor = connection.cursor()

        # SELECT so'rovini bajarish
        query = "SELECT time_quiz FROM tests WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))

        # Natijani olish
        result = cursor.fetchone()
        if result:
            return result[0]  # `time_quiz` qiymati
        else:
            return None  # test_uid topilmadi
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
async def check_random_question(test_uid):
    connection = db_connection()
    if not connection:
        return False

    cursor = connection.cursor()
    query = """
        SELECT random_question 
        FROM tests 
        WHERE test_uid = %s
    """
    cursor.execute(query, (test_uid,))
    result = cursor.fetchone()
    connection.close()

    return result[0] == 1 if result else False

async def check_random_options(test_uid):
    """
    Random variantlar tartibini tekshiradi.
    :param test_uid: Test UID
    :return: True agar random bo'lsa, aks holda False
    """
    connection = None
    try:
        connection = db_connection()
        cursor = connection.cursor()

        query = "SELECT random_options FROM tests WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        result = cursor.fetchone()
        return result[0] if result else False
    except Exception as e:
        print(f"Xato: {e}")
        return False
    finally:
        if connection:
            connection.close()

async def send_results(user_id, test_uid):
    lang = await get_user_language(user_id)
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Foydalanuvchining javoblarini olish
        query = """
            SELECT is_correct, skipped 
            FROM user_answers 
            WHERE user_id = %s AND test_uid = %s
        """
        cursor.execute(query, (user_id, test_uid))
        user_answers = cursor.fetchall()

        correct_answers = 0
        wrong_answers = 0
        skipped_questions = 0

        # Javoblarni tahlil qilish
        for is_correct, skipped in user_answers:
            if skipped == 1:
                skipped_questions += 1
            elif is_correct == 1:
                correct_answers += 1
            elif is_correct == 0:
                wrong_answers += 1

        # Test natijalarini yuborish
        result_text = f"✅{get_translation(lang, "correct_answers")} {correct_answers}\n"
        result_text += f"❌{get_translation(lang, "wrong_answers")} {wrong_answers}\n"
        result_text += f"⌛️{get_translation(lang, "missed")} {skipped_questions}"
        await save_test_results(user_id, test_uid, correct_answers, wrong_answers, skipped_questions)

        await bot.send_message(chat_id=user_id, text=result_text)

    except Exception as e:
        print(f"Xato: {e}")



async def check_and_start_test(user_id, test_uid):
    """
    Testni boshlashga ruxsatni tekshirish funksiyasi.
    lang = await get_user_language(user_id)
    """
    lang = await get_user_language(user_id)
    connection = None
    try:
        connection = db_connection()
        cursor = connection.cursor()

        # Avval bu testni boshlaganmi yoki yo'qmi tekshiramiz
        query = "SELECT COUNT(*) FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        count = cursor.fetchone()[0]

        if count > 0:
            await bot.send_message(chat_id=user_id, text=get_translation(lang, "already_test"))
            return False

        return True
    except Exception as e:
        print(f"Xato: {e}")
        return False
    finally:
        if connection:
            connection.close()


def get_prize_for_test(test_uid: str) -> float:
    # Bazaga ulanish
    conn = db_connection()
    if not conn:
        raise Exception("Ma'lumotlar bazasi bilan bog'lanishda xatolik yuz berdi.")

    try:
        cursor = conn.cursor()

        # Testga tegishli prize qiymatini olish
        cursor.execute("SELECT prize FROM tests WHERE test_uid = %s", (test_uid,))
        prize_row = cursor.fetchone()

        if prize_row is None:
            raise ValueError("Test topilmadi yoki prize ma'lumoti mavjud emas.")

        return prize_row[0]  # prize - testga tegishli mukofot miqdori
    except Exception as e:
        raise Exception(f"Xatolik yuz berdi: {str(e)}")
    finally:
        conn.close()


async def save_test_results(user_id, test_uid, correct_answers, wrong_answers, skipped_questions):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Umumiy ballni hisoblash (masalan, to'g'ri javoblar soni asosida)
        total_score = correct_answers

        # Test natijalarini saqlash
        query = """
            INSERT INTO test_results (user_id, test_uid, correct_answers, wrong_answers, skipped_questions, total_score, test_completed_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (user_id, test_uid, correct_answers, wrong_answers, skipped_questions, total_score, datetime.now()))
        connection.commit()

    except Exception as e:
        print(f"Xato: {e}")


def get_current_question_index(user_id):
    """Foydalanuvchining hozirgi savol indeksini qaytaradi."""
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)  # Dictionary cursorni o'rnating
    try:
        query = "SELECT currentQuestionIndex FROM users WHERE user_id = %s"
        cursor.execute(query, (user_id,))
        row = cursor.fetchone()
        return row['currentQuestionIndex'] if row else None
    finally:
        cursor.close()
        conn.close()
def increment_question_index(user_id):
    """Foydalanuvchi uchun savol indeksini 1 ga oshiradi."""
    conn = db_connection()
    cursor = conn.cursor()

    try:
        query = "UPDATE users SET currentQuestionIndex = currentQuestionIndex + 1 WHERE user_id = %s"
        cursor.execute(query, (user_id,))
        conn.commit()

    finally:
       cursor.close()
       conn.close()


def set_question_index(user_id, index):
    """Foydalanuvchi uchun savol indeksini belgilaydi."""
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        query = "UPDATE users SET currentQuestionIndex = %s WHERE user_id = %s"
        cursor.execute(query, (index, user_id))
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def save_poll_metadata(user_id, poll_id, question_id, sent_time):
    # Ma'lumotlar bazasiga yozish
    connection = db_connection()
    cursor = connection.cursor()
    query = """
        INSERT INTO polls (user_id, poll_id, question_id, sent_time)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (user_id, poll_id, question_id, sent_time))
    connection.commit()
    connection.close()

def is_answer_received(user_id, poll_id):
    # Poll javobining mavjudligini tekshirish
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT COUNT(*) FROM user_answers WHERE poll_id = %s AND user_id = %s"
    cursor.execute(query, (poll_id, user_id))
    result = cursor.fetchone()
    connection.close()
    return result[0] > 0

def get_question_by_id(test_uid, question_id):
    # Savolni olish uchun ma'lumotlar bazasi so'rovi
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM questions WHERE test_uid = %s AND question_id = %s"
    cursor.execute(query, (test_uid, question_id))
    question = cursor.fetchone()
    connection.close()
    return question

def get_answers_by_question_id(test_uid, question_id):
    # Javob variantlarini olish
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM answers WHERE test_uid = %s AND question_id = %s ORDER BY place_id"
    cursor.execute(query, (test_uid, question_id))
    answers = cursor.fetchall()
    connection.close()
    return answers
def add_question(conn, test_uid, question, question_id):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO questions (test_uid, question_text, question_id) VALUES (%s, %s, %s)
    """, (test_uid, question, question_id))
    conn.commit()


# Funksiya: Bazaga javob qo'shish
def add_answer(conn, question_id, test_uid, text, is_correct, option_index):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO answers (question_id, test_uid, answer_text, is_correct, place_id)
        VALUES (%s, %s, %s, %s, %s)
    """, (question_id, test_uid, text, is_correct, option_index))
    conn.commit()

async def get_user_currency(user_id: int) -> int:
    """
    Foydalanuvchining valyutasini olish.
    """
    conn = db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT currency FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        return result[0] if result else 1  # Default UZS
    finally:
        cursor.close()
        conn.close()

def get_currency_name(currency_id: int) -> str:
    """
    Valyuta identifikatorini nomga o'zgartirish.
    """
    currency_map = {1: "UZS", 2: "RUB", 3: "USD"}
    return currency_map.get(currency_id, "UZS")

def get_currency_card(currency: str) -> str:
    """
    Valyutaga mos kartani bazadan olish.
    """
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT card_number FROM admin WHERE currency_name = %s", (currency,))
    card = cursor.fetchone()
    cursor.close()
    conn.close()
    return card[0] if card else None

async def get_coin_balance(user_id: int):
    """
    Foydalanuvchining tangalar balansini va tanlangan valyutadagi qiymatini hisoblash.
    :param user_id: Telegram foydalanuvchisi ID
    :return: (coin_balance, calculated_balance, currency_name)
    """
    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchining balans va valyutasini olish
    cursor.execute("SELECT balance, currency FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        cursor.close()
        conn.close()
        return None, None, None

    coin_balance, currency = user_data

    # Valyuta bo'yicha narxni olish
    currency_map = {1: "UZS", 2: "RUB", 3: "USD"}
    cursor.execute("SELECT rate FROM admin WHERE currency_name = %s", (currency_map[currency],))
    rate_data = cursor.fetchone()

    cursor.close()
    conn.close()

    if not rate_data:
        return coin_balance, None, None

    rate = rate_data[0]
    calculated_balance = coin_balance * rate
    return coin_balance, calculated_balance, currency_map[currency]

async def send_balance_message(user_id: int, lang: int, message: Message):
    """
    Foydalanuvchiga balansni va hisoblangan qiymatni ko'rsatish.
    """
    coin_balance, calculated_balance, currency_name = await get_coin_balance(user_id)

    if coin_balance is None:
        await message.answer(get_translation(lang, "user_notfound"))
        return

    # Xabar matni
    balance_message = (
        f"💰 {get_translation(lang, 'your_balance')}: {coin_balance} {get_translation(lang, 'coins')}\n"
        f"💱 {get_translation(lang, 'balance_value')}: {calculated_balance:.2f} {currency_name}\n\n"
        f"{get_translation(lang, 'choose_action')}"
    )

    # Tugmalar bilan jo'natish
    keyboard = create_balance_keyboard(lang)
    await message.answer(balance_message, reply_markup=keyboard)

async def get_user_coin_balance_and_value(user_id: int):
    """
    Foydalanuvchining balansidagi tangalar va hisoblangan valyutadagi qiymatini olish.
    """
    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchi balansini va valyutasini olish
    cursor.execute("SELECT balance, currency FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        cursor.close()
        conn.close()
        return None, None, None

    coin_balance, currency = user_data

    # Valyuta kursini olish
    currency_map = {1: "UZS", 2: "RUB", 3: "USD"}
    cursor.execute("SELECT rate FROM admin WHERE currency_name = %s", (currency_map[currency],))
    rate_data = cursor.fetchone()

    cursor.close()
    conn.close()

    if not rate_data:
        return coin_balance, None, None

    rate = rate_data[0]
    calculated_balance = coin_balance * rate
    return coin_balance, calculated_balance, currency_map[currency]



async def handle_balance(user_id: int,message:Message):

    user_id = user_id
    lang = await get_user_language(user_id)  # Foydalanuvchining tilini olish
    coin_balance, calculated_value, currency = await get_user_coin_balance_and_value(user_id)

    if coin_balance is None:
        await message.answer(get_translation(lang, "user_notfound"))
        return

    # Balans xabari
    balance_message = (
        f"💰 {get_translation(lang, 'your_balance')}: {coin_balance} {get_translation(lang, 'coins')}\n"
        f"💱 {get_translation(lang, 'balance_value')}: {calculated_value:.2f} {currency}\n\n"
        f"{get_translation(lang, 'choose_action')}"
    )

    balance_menu = create_balance_keyboard(lang)  # Asosiy menyu tugmalari
    await message.answer(balance_message, reply_markup=balance_menu)


def update_user_balance(user_id: int, stars: int) -> None:
    """
    Foydalanuvchining balansini yangilash.
    :param user_id: Telegram foydalanuvchi ID
    :param stars: Qo'shiladigan Telegram Stars miqdori
    """
    try:
        conn = db_connection()
        cursor = conn.cursor()

        # Foydalanuvchi balansini yangilash
        cursor.execute(
            "UPDATE users SET balance = balance + %s WHERE user_id = %s",
            (stars, user_id)
        )

        conn.commit()
        cursor.close()
        conn.close()

        print(f"Balans yangilandi: User ID = {user_id}, Stars = {stars}")
    except Exception as e:
        print(f"Balansni yangilashda xatolik yuz berdi: {e}")


def get_user_coin_balance(user_id: int) -> int:
    """
    Foydalanuvchining Telegram Stars (XTR) balansini olish.
    :param user_id: Telegram foydalanuvchi ID
    :return: Telegram Stars miqdori
    """
    try:
        conn = db_connection()
        cursor = conn.cursor()

        # Foydalanuvchi balansini olish
        cursor.execute(
            "SELECT balance FROM users WHERE user_id = %s",
            (user_id,)
        )
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if result:
            return result[0]  # Foydalanuvchining balansi
        else:
            print(f"Foydalanuvchi topilmadi: User ID = {user_id}")
            return None
    except Exception as e:
        print(f"Balansni olishda xatolik yuz berdi: {e}")
        return None


