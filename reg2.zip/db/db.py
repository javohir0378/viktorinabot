import random

import mysql.connector
from aiogram.enums import PollType
from aiogram.types import Message
from mysql.connector import Error
import asyncio
from datetime import datetime
from app import bot


def db_connection():
    """
    MySQL database connection function.
    Returns:
        conn: Database connection object or None if failed.
    """
    try:
        conn = mysql.connector.connect(
            host="185.253.217.251",
            user="yculjjxo_admin",
            password="sadiso0307",
            database="yculjjxo_quizbot",
            autocommit=True  # Avtomatik commit qilishni yoqish (zaruratga qarab sozlang)
        )
        if conn.is_connected():
            print("Database connection successful!")
        return conn
    except Error as err:
        if err.errno == 1045:
            print("Error: Access denied - Incorrect username or password")
        elif err.errno == 1049:
            print("Error: Unknown database specified")
        elif err.errno == 2003:
            print("Error: Cannot connect to the database server")
        elif err.errno == 2005:
            print("Error: Unknown MySQL server host")
        else:
            print(f"Error: {err}")
        return None

