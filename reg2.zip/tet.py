from aiogram import Bot, Dispatcher, F, types
from aiogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.filters import Command
from aiogram import Router
from aiogram_media_group import media_group_handler
import asyncio

from data import config

# Bot tokeningizni o'rnating
BOT_TOKEN = "5742010455"

# Bot va Dispatcher
bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher()

# Admin ID ro'yxati
ADMINS = [5742010455, 1055073877]  # Adminlarning ID'larini yozing

# Buyurtma berish tugmasi
def get_order_button():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Buyurtma Berish", callback_data="order")]
        ]
    )

# Rasmli xabarlarni qayta ishlash
async def handle_photo_message(message: Message):
    # Faqat adminlardan kelgan xabarlarni qayta ishlash
    if message.from_user.id in ADMINS and message.photo:
        try:
            # Rasmdan foydalanish uchun file_id ni olamiz
            photo_id = message.photo[-1].file_id  # Eng yuqori sifatli rasmdan foydalaniladi

            # caption mavjudligini tekshiramiz
            if message.caption:
                parts = [part.strip() for part in message.caption.split(",")]

                # Mavjud segmentlar uchun qiymatlarni ajratib olish
                narxi = parts[0] if len(parts) > 0 and parts[0] else None
                hajmi = parts[1] if len(parts) > 1 and parts[1] else None
                kargo = parts[2] if len(parts) > 2 and parts[2] else None
                muddat = parts[3] if len(parts) > 3 and parts[3] else None
                dp = parts[4] if len(parts) > 4 and parts[4] else None
                # Formatlangan ma'lumotlarni yig'ish
                details = []
                if narxi:
                    details.append(f"📌 *Narxi:* {narxi}")
                if hajmi:
                    details.append(f"📦 *Hajmi:* {hajmi}")
                if kargo:
                    details.append(f"✈️ *Kargo:* {kargo}")
                if muddat:
                    details.append(f"⏳ *Yetkazib berish muddati:* {muddat}")
                if dp:
                    details.append(f"📎 *Qo'shimcha ma'lumot:* {dp}")

                if details:
                    formatted_caption = "🛒 *Buyurtma tafsilotlari:*\n" + "\n".join(details)
                else:
                    formatted_caption = "⚠️ Matn formati noto'g'ri yoki to'liq emas!"

                # Tugma qo'shish
                reply_markup = get_order_button()

                # Media guruhda birinchi rasmga caption qo'shamiz va tugma qo'shamiz
                media = [
                    types.InputMediaPhoto(
                        media=photo_id,
                        caption=formatted_caption,
                        parse_mode="Markdown",
                        reply_markup=reply_markup
                    )
                ]

                # Media guruhni yuboramiz
                await bot.send_media_group(chat_id=message.chat.id, media=media)

            else:
                # caption bo'lmasa, xabar chiqaramiz
                await bot.send_message(chat_id=message.chat.id, text="⚠️ Matn mavjud emas.")

            # Adminning asl xabarini o'chirish
            await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
        except Exception as e:
            print(f"Xatolik yuz berdi: {e}")


# Media guruh xabarlarini qayta ishlash
@dp.message(F.media_group_id, F.content_type.in_({'photo'}))
@media_group_handler
async def handle_media_group(messages: list[Message]):
    if all(msg.from_user.id in ADMINS for msg in messages):
        try:
            # Media guruh oxiridagi xabarning captionini ishlatamiz
            caption = messages[0].caption  # Birinchi rasmning caption'ini olish

            if not caption:
                formatted_caption = "⚠️ Matn mavjud emas."
            else:
                # caption'ni qayta ishlash va bo'sh segmentlarni chiqarib tashlash
                parts = [part.strip() for part in caption.split(",")]

                # Mavjud segmentlar uchun qiymatlarni ajratib olish
                narxi = parts[0] if len(parts) > 0 and parts[0] else None
                hajmi = parts[1] if len(parts) > 1 and parts[1] else None
                kargo = parts[2] if len(parts) > 2 and parts[2] else None
                muddat = parts[3] if len(parts) > 3 and parts[3] else None
                dp = parts[4] if len(parts) > 4 and parts[4] else None

                # Formatlangan ma'lumotlarni yig'ish
                details = []
                if narxi:
                    details.append(f"📌 *Narxi:* {narxi}")
                if hajmi:
                    details.append(f"📦 *Hajmi:* {hajmi}")
                if kargo:
                    details.append(f"✈️ *Kargo:* {kargo}")
                if muddat:
                    details.append(f"⏳ *Yetkazib berish muddati:* {muddat}")
                if dp:
                    details.append(f"📎 *Qo'shimcha ma'lumot:* {dp}")

                if details:
                    formatted_caption = "🛒 *Buyurtma tafsilotlari:*\n" + "\n".join(details)
                else:
                    formatted_caption = "⚠️ Matn formati noto'g'ri yoki to'liq emas."

            # Media guruh uchun media obyektini yaratamiz
            media = [
                types.InputMediaPhoto(
                    media=m.photo[-1].file_id,
                    caption=formatted_caption if i == len(messages) - 1 else None,
                    parse_mode="Markdown",
                    reply_markup=get_order_button() if i == len(messages) - 1 else None  # Tugma faqat oxirgi rasmga qo'shiladi
                )
                for i, m in enumerate(messages)
            ]

            # Media guruhni yuboramiz
            await bot.send_media_group(chat_id=messages[-1].chat.id, media=media)

            # Asl xabarlarni o'chiramiz
            for msg in messages:
                await bot.delete_message(chat_id=msg.chat.id, message_id=msg.message_id)

        except Exception as e:
            print(f"Xatolik yuz berdi: {e}")


@dp.callback_query(F.data == "order")
async def handle_order_button(callback_query: types.CallbackQuery):
    try:
        # Agar foydalanuvchi "Buyurtma Berish" tugmasini bossa
        original_message = callback_query.message
        caption = original_message.caption if original_message.caption else "⚠️ Matn mavjud emas."

        # Adminlarga xabar yuborish
        for admin_id in ADMINS:
            await bot.send_message(
                admin_id,
                f"🛒 *Buyurtma yuborildi:*\n\n{caption}",
                parse_mode="Markdown"
            )

        # Foydalanuvchiga tasdiqlash xabarini yuborish
        await callback_query.answer("Buyurtmangiz adminlarga yuborildi!", show_alert=True)

    except Exception as e:
        print(f"Xatolik yuz berdi: {e}")


# Routerni sozlaymiz
router = Router()
router.message.register(handle_photo_message, F.photo)

# Media group uchun middlewareni qo'shish
# dp.message.middleware(MediaGroupMiddleware())
dp.include_router(router)


# Asosiy ishga tushirish funksiyasi
async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
