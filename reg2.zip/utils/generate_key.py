import random
import string

def rand_string(length: int) -> str:
    """Generate a random string of specified length."""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))
