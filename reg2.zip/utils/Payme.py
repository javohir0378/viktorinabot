import requests

class Payme:
    def __init__(self, mycard):
        self.mycard = mycard

    def create(self, summ, desc="#UzbProMax"):
        summa = summ * 100
        result = dict()

        response = requests.post(
            'https://payme.uz/api/p2p.create',
            json={"method": "p2p.create", "params": {"card_id": self.mycard, "amount": summa, "description": desc}},
            headers={'device': '6Fk1rB', 'user-agent': 'Mozilla/57.36'}
        ).json()

        if "result" in response:
            result['ok'] = True
            result['result'] = {
                'id': response['result']['cheque']['_id'],
                'amount': f'{summ} UZS',
                'pay_url': f"https://checkout.paycom.uz/{response['result']['cheque']['_id']}"
            }
        else:
            result['ok'] = False
            result['error'] = response.get('error')

        return result

    def info(self, check_id):
        result = dict()

        response = requests.post(
            'https://payme.uz/api/cheque.get',
            json={"method": "cheque.get", "params": {"id": check_id}},
            headers={'device': '6Fk1rB', 'user-agent': 'Mozilla/57.36'}
        ).json()

        try:
            r = response['result']['cheque']['pay_time']
            if r:
                result['ok'] = True
                result['payment'] = 'successfully'
            else:
                result['ok'] = True
                result['payment'] = 'unsuccessfully'
        except:
            result['ok'] = False
            result['error'] = response.get('error')

        return result
