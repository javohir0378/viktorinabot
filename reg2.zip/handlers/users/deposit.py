from aiogram import Router, types, F
from aiogram.filters import StateFilter
from aiogram.types import LabeledPrice, PreCheckoutQuery, InlineKeyboardMarkup, InlineKeyboardButton, Message
from aiogram.fsm.context import FSMContext
from aiogram.utils.chat_action import logger

from app import bot
from db.function import update_user_balance, get_user_coin_balance
from keyboards.reply.keyboards import create_balance_keyboard
from lang.translate import get_user_language, get_translation
from states.test import DepositStates, QuizStates

router = Router()

# Minimal va maksimal yulduzlar miqdori
MIN_STARS = 1
MAX_STARS = 1000

# To'lov provayder tokeni
PAYMENT_PROVIDER_TOKEN = "YOUR_PROVIDER_TOKEN_HERE"

# Balansni ko'rsatish tugmasi
def create_balance_button(lang: int):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=get_translation(lang, "check_balance"),
                    callback_data="check_balance"
                )
            ]
        ]
    )

@router.callback_query(F.data == "deposit")
async def start_deposit(callback: types.CallbackQuery, state: FSMContext):
    """
    Telegram Stars sotib olishni boshlash.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)

    # Minimal va maksimal miqdorlarni ko'rsatish
    await callback.message.answer(
        f"{get_translation(lang, 'deposit_prompt')}\n"
        f"💳 {get_translation(lang, 'minimum_amount')}: {MIN_STARS} XTR\n"
        f"💳 {get_translation(lang, 'maximum_amount')}: {MAX_STARS} XTR\n"
        f"{get_translation(lang, 'enter_amount')}"
    )
    await state.set_state(DepositStates.enter_amount)


@router.message(StateFilter(DepositStates.enter_amount))
async def handle_amount(message: types.Message, state: FSMContext):
    """
    Foydalanuvchi yulduzlar miqdorini kiritganda.
    """
    user_id = message.from_user.id
    lang = await get_user_language(user_id)

    # Xabar matnini tekshirish
    if not message.text or not message.text.isdigit():
        await message.answer(
            get_translation(lang, "invalid_amount").format(
                min_stars=MIN_STARS, max_stars=MAX_STARS
            )
        )
        return

    amount = int(message.text)
    # Miqdorni tekshirish
    if amount < MIN_STARS or amount > MAX_STARS:
        await message.answer(
            get_translation(lang, "amount_out_of_range").format(
                min_stars=MIN_STARS, max_stars=MAX_STARS
            )
        )
        return

    # Yulduzlar miqdorini saqlash va to'lovni boshlash
    await state.update_data(amount=amount)
    await state.set_state(QuizStates.HOME)
    await bot.send_invoice(
        message.chat.id,
        title="Telegram Stars",
        description=f"{amount} XTR sotib olish",
        payload=f"purchase-{amount}",
        provider_token=PAYMENT_PROVIDER_TOKEN,
        currency="XTR",
        prices=[LabeledPrice(label="Telegram Stars", amount=amount)],  # Miqdorni centlarga aylantirish
        start_parameter="buy_stars"
    )



@router.pre_checkout_query()
async def checkout(query: PreCheckoutQuery):
    """
    To'lovni tasdiqlash.
    """
    await query.bot.answer_pre_checkout_query(query.id, ok=True)

@router.message(F.successful_payment)
async def handle_successful_payment(message: types.Message, state: FSMContext):
    """
    To'lov muvaffaqiyatli bo'lganda.
    """
    user_id = message.from_user.id
    lang = await get_user_language(user_id)
    data = await state.get_data()
    amount = data.get("amount")
    print(amount)
    # Miqdorni tekshirish
    if amount is None or amount < MIN_STARS or amount > MAX_STARS:
        await message.answer(
            get_translation(lang, "invalid_amount").format(
                min_stars=MIN_STARS, max_stars=MAX_STARS
            )
        )
        return

    # Foydalanuvchining balansini yangilash
    update_user_balance(user_id, amount)

    coin_balance = get_user_coin_balance(user_id)

    if coin_balance is None:
        await message.answer(get_translation(lang, "user_notfound"))
        return # Asosiy menyu tugmalari
    balance_message = f"💰 {get_translation(lang, 'your_balance')}: {coin_balance} XTR"

    await message.answer(
        get_translation(lang, "purchase_success").format(amount=amount)+"\n"+balance_message,
        message_effect_id="5046509860389126442",
        reply_markup=create_balance_keyboard(lang)
    )
    await state.clear()



@router.callback_query(F.data == "check_balance")
async def check_balance(callback: types.CallbackQuery):
    """
    Foydalanuvchi balansni ko'rsatish tugmasini bosganda.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)

    # Balansni olish va foydalanuvchiga ko'rsatish
    balance = get_user_coin_balance(user_id)
    await callback.message.answer(
        get_translation(lang, "current_balance").format(balance=balance)
    )
