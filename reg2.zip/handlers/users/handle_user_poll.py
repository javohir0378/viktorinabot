from aiogram import types, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from app import dp
from db.db import db_connection
from db.function import add_answer
from keyboards.reply.keyboards import create_main_menu_keyboard
from lang.translate import get_user_language, get_translation
from states.test import QuizStates

router = Router()


# Media yoki fayl qabul qilish
# Media yoki fayl qabul qilish
@router.message(F.content_type.in_({types.ContentType.PHOTO, types.ContentType.VIDEO, types.ContentType.DOCUMENT}), QuizStates.ADD_QUESTIONS)
async def handle_media(message: types.Message, state: FSMContext):
    file_id = None
    media_type = None

    # Fayl ID va turini aniqlash
    if message.photo:
        file_id = message.photo[-1].file_id
        media_type = "photo"
    elif message.video:
        file_id = message.video.file_id
        media_type = "video"
    elif message.document:
        file_id = message.document.file_id
        media_type = "document"

    if file_id and media_type:
        await state.update_data(media=file_id, media_type=media_type)
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "media_file_received"))
    else:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "incorrect_file_type"))

# Quiz Pollni qabul qilish
# Quiz Pollni qabul qilish
@router.message(F.content_type == types.ContentType.POLL, QuizStates.ADD_QUESTIONS)
async def handle_user_poll(message: types.Message, state: FSMContext):
    poll = message.poll
    question = poll.question
    options = poll.options
    correct_option_id = poll.correct_option_id
    lang = await get_user_language(message.from_user.id)
    data = await state.get_data()
    test_uid = data.get("test_uid")
    media = data.get("media")  # Oldin yuborilgan media
    media_type = data.get("media_type")  # Media turi

    if not test_uid:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "test_id_not_found"))
        return

    # Bazaga ulanish
    conn = db_connection()
    if not conn:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "db_connection_error"))
        return

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM questions WHERE test_uid = %s", (test_uid,))
        question_count = cursor.fetchone()[0]

        # Savolni SQL bazasiga qo'shish
        question_id = question_count + 1
        cursor.execute(
            "INSERT INTO questions (test_uid, question_text, question_id, addition, media_type) VALUES (%s, %s, %s, %s, %s)",
            (test_uid, question, question_id, media, media_type),
        )
        conn.commit()

        # Variantlarni qo'shish
        for index, option in enumerate(options):
            is_correct = 1 if index == correct_option_id else 0
            add_answer(conn, question_id, test_uid, option.text, is_correct, index)

        # Foydalanuvchiga tasdiq xabari
        response_text = get_translation(lang, "question_added") + "\n" + get_translation(lang, "question_text").format(question_id=question_id, question=question) + "\n" + get_translation(lang, "options_text").format(options=', '.join([opt.text for opt in options]))
        await message.reply(response_text)
        await message.reply(get_translation(lang, "send_new_question"))

        # Holatni tozalash
        await state.update_data(media=None, media_type=None)
    except Exception as e:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "unknown_error").format(error_message=str(e)))
    finally:
        conn.close()

# /undo komandasi
@router.message(Command("undo"), QuizStates.ADD_QUESTIONS)
async def undo_last_question(message: types.Message, state: FSMContext):
    data = await state.get_data()
    test_uid = data.get("test_uid")

    if not test_uid:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "test_id_not_found"))
        return

    # Oxirgi savolni olish va o'chirish
    conn = db_connection()
    if not conn:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "db_connection_error"))
        return

    try:
        cursor = conn.cursor()

        # Oxirgi savolni aniqlash
        cursor.execute(
            "SELECT question_id FROM questions WHERE test_uid = %s ORDER BY question_id DESC LIMIT 1",
            (test_uid,)
        )
        last_question = cursor.fetchone()

        if not last_question:
            lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
            await message.reply(get_translation(lang, "undo_command_error"))
            return

        last_question_id = last_question[0]

        # Savol va unga tegishli variantlarni o'chirish
        cursor.execute("DELETE FROM answers WHERE question_id = %s AND test_uid = %s", (last_question_id, test_uid))
        cursor.execute("DELETE FROM questions WHERE question_id = %s AND test_uid = %s", (last_question_id, test_uid))
        conn.commit()

        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "undo_question_deleted").format(question_id=last_question_id))
    except Exception as e:
        lang = await get_user_language(message.from_user.id)  # Foydalanuvchi tilini olish
        await message.reply(get_translation(lang, "unknown_error").format(error_message=str(e)))
    finally:
        conn.close()
