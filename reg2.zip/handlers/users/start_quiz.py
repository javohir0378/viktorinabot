import asyncio
import datetime
import random

from aiogram import types, F, Router
from aiogram.enums import PollType
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, PollAnswer, InlineKeyboardMarkup, InlineKeyboardButton

from app import dp, bot
from db.function import send_results, check_random_question, send_question
from lang.translate import get_user_language, get_translation

router = Router()


from aiogram import types
from aiogram.fsm.context import FSMContext
from db.db import db_connection

from collections import defaultdict

# Guruhda testga qo'shilgan foydalanuvchilarni kuzatish uchun lug'at
group_participants = defaultdict(set)


@router.callback_query(F.data.startswith("start_quiz:"))
async def start_quiz(callback: types.CallbackQuery, state: FSMContext):
    chat_id = callback.message.chat.id
    user_id = callback.message.chat.id
    test_uid = callback.data.split(":")[1]
    lang = await get_user_language(user_id)
    connection = None
    try:
        connection = db_connection()
        if not connection:
            await callback.message.answer("Xatolik: Baza bilan bog'lanishda muammo yuz berdi.")
            return

        cursor = connection.cursor()

        # Testning holatini tekshirish (test_status = 1 yoki 0)
        query = "SELECT status FROM tests WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        test_status_row = cursor.fetchone()

        if test_status_row is None or test_status_row[0] == 0:
            # Test faol emasligi haqida xabar yuborish
            await callback.message.answer(get_translation(lang, "test_not_active"))
            return

        # G'olib aniqlanganligini tekshirish
        query = """
            SELECT u.username 
            FROM test_results tr
            JOIN users u ON tr.user_id = u.user_id
            WHERE tr.test_uid = %s AND tr.is_winner = 1
            LIMIT 1
        """
        cursor.execute(query, (test_uid,))
        winner_row = cursor.fetchone()

        if winner_row:
            winner_username = f"@{winner_row[0]}" if winner_row[0] else get_translation(lang, "winner")

            # Ogohlantiruvchi xabar
            warning_message = (
                f"📢 <b>Diqqat!</b>\n\n"
                f"Ushbu testda allaqachon g'olib aniqlangan: {winner_username}.\n\n"
                f"Testni qayta boshlamoqchimisiz?"
            )

            # Tugmalarni yaratish
            keyboard = InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text=get_translation(lang, "start_quiz"), callback_data=f"confirm_start:{test_uid}")],
                    [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="cancel_start")]
                ]
            )

            # Ogohlantirish xabarini yuborish
            await callback.message.answer(warning_message, reply_markup=keyboard, parse_mode="HTML")
            return

        # Test savollarini olish
        query = "SELECT question_id FROM questions WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        all_questions = [row[0] for row in cursor.fetchall()]

        if not all_questions:
            await callback.message.answer(get_translation(lang, "notfound_questions"))
            return

        # Pollsda yuborilgan savollarni aniqlash
        query = "SELECT question_id FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        sent_questions = [row[0] for row in cursor.fetchall()]

        # Qolgan savollarni aniqlash
        remaining_questions = list(set(all_questions) - set(sent_questions))
        if not remaining_questions:
            await callback.message.answer(get_translation(lang, "already_test"))
            await send_results(user_id, test_uid)
            return

        # Random yoki birinchi savolni tanlash
        random_question = await check_random_question(test_uid)
        question_id = random.choice(remaining_questions) if random_question else min(remaining_questions)
        # 3-dan 1-gacha hisoblagich va "Qani, ketdik!" xabari
        countdown_message = await callback.message.answer("3")
        for i in range(2, 0, -1):
            await asyncio.sleep(1)
            await countdown_message.edit_text(str(i))
        await asyncio.sleep(1)
        await countdown_message.edit_text(get_translation(lang, "lets_go"))
        await asyncio.sleep(1)
        await countdown_message.delete()
        await send_question(callback.message.chat.id, test_uid, question_id)

    except Exception as e:
        print(f"Xato: {e}")
        await callback.message.answer("Xatolik yuz berdi. Keyinroq urinib ko'ring.")
    finally:
        if connection:
            connection.close()


@router.callback_query(F.data.startswith("confirm_start:"))
async def confirm_start(callback: types.CallbackQuery):
    test_uid = callback.data.split(":")[1]
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)
    # Testni boshlash
    connection = None
    try:
        connection = db_connection()
        if not connection:
            await callback.message.answer("Xatolik: Baza bilan bog'lanishda muammo yuz berdi.")
            return

        cursor = connection.cursor()
        query = "SELECT question_id FROM questions WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        all_questions = [row[0] for row in cursor.fetchall()]

        if not all_questions:
            await callback.message.answer(get_translation(lang, "notfound_questions"))
            return

        # Pollsda yuborilgan savollarni aniqlash
        query = "SELECT question_id FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        sent_questions = [row[0] for row in cursor.fetchall()]

        # Qolgan savollarni aniqlash
        remaining_questions = list(set(all_questions) - set(sent_questions))
        if not remaining_questions:
            await callback.message.answer(get_translation(lang, "already_test"))
            await send_results(user_id, test_uid)
            return

        # Random yoki birinchi savolni tanlash
        random_question = await check_random_question(test_uid)
        question_id = random.choice(remaining_questions) if random_question else min(remaining_questions)
        # 3-dan 1-gacha hisoblagich va "Qani, ketdik!" xabari
        countdown_message = await callback.message.answer("3")
        for i in range(2, 0, -1):
            await asyncio.sleep(1)
            await countdown_message.edit_text(str(i))
        await asyncio.sleep(1)
        await countdown_message.edit_text("Qani, ketdik!")
        await asyncio.sleep(1)
        await countdown_message.delete()
        await send_question(callback.message.chat.id, test_uid, question_id)
    except Exception as e:
        print(f"Xato: {e}")
        await callback.message.answer("Xatolik yuz berdi. Keyinroq urinib ko'ring.")
    finally:
        if connection:
            connection.close()
    await start_quiz(callback, None)


@router.callback_query(F.data.startswith("cancel_start"))
async def cancel_start(callback: types.CallbackQuery):
    # Testni bekor qilish
    await callback.message.answer("Test boshlash bekor qilindi.")