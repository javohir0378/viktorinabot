import mysql.connector

# MySQLga ulanish
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host="79.174.88.137",
            port=15506,
            user="sadisoadmin",
            password="Sadiso0307@@",
            database="viktoronadb"
        )
        if connection.is_connected():
            print("Ma'lumotlar bazasiga ulanish muvaffaqiyatli!")
        return connection
    except mysql.connector.Error as err:
        print(f"Xatolik yuz berdi: {err}")
        return None

# SQL faylni o'qish va bajarish
def execute_sql_file(connection, file_path):
    try:
        with open(file_path, 'r') as file:
            sql_commands = file.read()
        cursor = connection.cursor()
        for command in sql_commands.split(';'):
            if command.strip():
                cursor.execute(command)
        connection.commit()
        print("SQL fayl muvaffaqiyatli yuklandi!")
    except Exception as e:
        print(f"Xatolik: {e}")
    finally:
        cursor.close()

# Ulanish va SQL faylni bajarish
db_connection = connect_to_database()
if db_connection:
    cursor = db_connection.cursor()
    cursor.execute("SHOW TABLES;")  # Masalan, mavjud jadvallarni ko'rish
    for table in cursor:
        print(table)

    # Ulanishni yopish
    cursor.close()
    db_connection.close()
    execute_sql_file(db_connection, "/root/viktorinabot/viktorinabot/yculjjxo_quizbot(2).sql")
    db_connection.close()
