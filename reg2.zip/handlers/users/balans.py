from aiogram import Router, types, F
from aiogram.filters.command import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from data.config import ADMINS
from db.function import get_user_coin_balance_and_value, get_user_coin_balance

from keyboards.reply.keyboards import create_balance_keyboard
from lang.translate import get_user_language, get_translation

router = Router()


@router.callback_query(F.data == "balance")
async def handle_balance_query(callback: CallbackQuery, state: FSMContext):
    """
    Balans tugmasi bosilganda foydalanuvchining balans va hisoblangan qiymatini chiqarish.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)  # Foydalanuvchining tilini olish
    #coin_balance, calculated_value, currency = await get_user_coin_balance_and_value(user_id)
    coin_balance = get_user_coin_balance(user_id)
    if coin_balance is None:
        await callback.message.answer(get_translation(lang, "user_notfound"))
        await callback.answer()
        return

    # Balans xabari



    # Balansni ko'rsatish
    balance_message = f"💰 {get_translation(lang, 'your_balance')}: {coin_balance} XTR"

    balance_menu = create_balance_keyboard(lang)  # Asosiy menyu tugmalari
    await callback.message.edit_text(balance_message, reply_markup=balance_menu)
    await callback.answer()  # Qo‘shimcha javob uchun ishlatish kerak


