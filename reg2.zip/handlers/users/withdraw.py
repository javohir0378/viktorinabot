from aiogram import  types, Router, F
from aiogram.filters import StateFilter
from aiogram.filters.command import Command
from aiogram.fsm.context import FSMContext

from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, PollAnswer,
    BotCommand, Poll
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from mysql.connector import Error

from data.config import ADMINS
from db.function import get_user_coin_balance_and_value
from keyboards.reply.keyboards import create_main_menu_keyboard
from app import QuizCallbackData
from db.db import db_connection
from lang.test import translations
from lang.translate import get_translation, get_user_language
from states.test import QuizStates, WithdrawStates

router = Router()


@router.callback_query(F.data == "withdraw")
async def start_withdraw(callback: types.CallbackQuery, state: FSMContext):
    """
    Foydalanuvchi "Pul yechib olish" tugmasini bosganda.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)  # Foydalanuvchining tilini olish

    # Foydalanuvchi balansini va valyutasini olish
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT balance, currency FROM users WHERE user_id = %s", (user_id,))
    result = cursor.fetchone()

    if not result:
        await callback.message.answer(get_translation(lang, "no_user_info"))
        cursor.close()
        conn.close()
        return

    balance, calculated_value, currency = await get_user_coin_balance_and_value(user_id)# result["balance"], result["currency"]
    cursor.execute("SELECT rate, min_withdraw, max_withdraw FROM admin WHERE currency_name = %s", (currency,))
    admin_info = cursor.fetchone()

    if not admin_info:
        await callback.message.answer(get_translation(lang, "no_currency_info"))
        cursor.close()
        conn.close()
        return

    rate = admin_info["rate"]
    min_withdraw = admin_info["min_withdraw"]
    max_withdraw = admin_info["max_withdraw"]

    # Ulanishni yopish
    cursor.close()
    conn.close()

    # Tanganing foydalanuvchi valyutasidagi narxi
    currency_value = 1 / rate

    # Foydalanuvchiga ma'lumot yuborish
    await callback.message.answer(
        f"{get_translation(lang, 'current_balance').format(balance=balance)}Stars\n"
        f"{get_translation(lang, 'min_withdraw')}: {min_withdraw} Stars\n"
        f"{get_translation(lang, 'max_withdraw')}: {max_withdraw} Stars\n\n"
        f"{get_translation(lang, 'enter_withdraw_amount')}"
    )
    await callback.message.delete()
    await callback.answer()
    await state.set_state(WithdrawStates.enter_amount)


@router.message(StateFilter(WithdrawStates.enter_amount))
async def validate_withdraw_amount(message: types.Message, state: FSMContext):
    """
    Foydalanuvchi tanga miqdorini kiritganda tekshiradi va tasdiqlashni so‘raydi.
    """
    user_id = message.from_user.id
    lang = await get_user_language(user_id)

    # Ma'lumotlar bazasidan foydalanuvchi balansini olish
    conn = None
    try:
        conn = db_connection()
        cursor = conn.cursor(dictionary=True)

        # Balans va valyuta haqida ma'lumotni olish
        cursor.execute("SELECT balance, currency FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()

        if not result:
            await message.answer(get_translation(lang, "no_user_info"))
            return

        balance, calculated_value, currency = await get_user_coin_balance_and_value(user_id)

        # Admin tomonidan belgilangan yechib olish chegaralarini olish
        cursor.execute("SELECT rate, min_withdraw, max_withdraw FROM admin WHERE currency_name = %s", (currency,))
        admin_info = cursor.fetchone()

        if not admin_info:
            await message.answer(get_translation(lang, "no_currency_info"))
            return

        rate = admin_info["rate"]
        min_withdraw = admin_info["min_withdraw"]
        max_withdraw = admin_info["max_withdraw"]

        # Kiritilgan qiymatni tekshirish
        if not message.text.isdigit():
            await message.answer(get_translation(lang, "invalid_withdraw_amount"))
            return

        withdraw_amount = int(message.text)

        if withdraw_amount < min_withdraw:
            await message.answer(get_translation(lang, "below_min_withdraw").format(min_withdraw=min_withdraw))
            return

        if withdraw_amount > max_withdraw:
            await message.answer(get_translation(lang, "above_max_withdraw").format(max_withdraw=max_withdraw))
            return

        if withdraw_amount > balance:
            await message.answer(get_translation(lang, "insufficient_balance"))
            return

        # Foydalanuvchidan tasdiqlashni so‘rash
        withdraw_value = withdraw_amount / rate
        await state.update_data(
            withdraw_amount=withdraw_amount,
            withdraw_value=withdraw_value,
            currency=currency,
        )
        await message.answer(
            f"💰 {get_translation(lang, 'withdraw_amount')}: {withdraw_amount} Stars\n"
            f"📤 {get_translation(lang, 'withdraw_value')}: {withdraw_value:.2f} {currency}\n\n"
            f"{get_translation(lang, 'confirm_withdraw')}",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text=get_translation(lang, 'confirm_button'), callback_data=f"confirm_withdraw_{message.from_user.id}_{withdraw_amount}")]
                ]
            )
        )
        await state.clear()
    except Error as e:
        await message.answer("Ma'lumotlar bazasi bilan bog‘liq muammo yuz berdi. Keyinroq urinib ko‘ring.")
        print(f"Database error: {e}")
    finally:
        if conn:
            conn.close()

@router.callback_query(F.data.startswith("confirm_withdraw"))
async def send_withdraw_request_to_admin(callback: types.CallbackQuery, state: FSMContext):
    """
    Admin va foydalanuvchiga yechib olish so'rovini yuborish.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)
    try:
        print(f"Callback Data: {callback.data}")
        data = callback.data.split("_")

        if len(data) < 3:
            await callback.message.answer("Callback ma'lumotlari noto'g'ri!")
            return

        user_id = callback.from_user.id
        withdraw_amount = int(data[3])

        # Foydalanuvchi ma'lumotlarini olish
        conn = db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT balance,fname, lname FROM users WHERE user_id = %s",
            (user_id,)
        )
        user_info = cursor.fetchone()

        cursor.close()
        conn.close()

        if not user_info:
            await callback.message.answer("Foydalanuvchi ma'lumotlari topilmadi!")
            return

        balance = user_info["balance"]
        fname = user_info["fname"]
        lname = user_info["lname"]

        # Admin uchun xabarni yuborish
        admin_message = (
            f"📤 **Pul yechish so'rovi**\n"
            f"👤 Foydalanuvchi: {fname} {lname}\n"
            f"💰 Hozirgi balansi: {balance}\n"
            f"💰 Yechish: {withdraw_amount} tanga \n"
        )

        for admin_id in ADMINS:
            await callback.message.bot.send_message(admin_id, admin_message)

        await callback.message.edit_text(get_translation(lang, "request_accept"))
        welcome_text = get_translation(lang, "welcome")
        keyboard = create_main_menu_keyboard(lang)

        await callback.message.answer(welcome_text, message_effect_id="5046509860389126442", reply_markup=keyboard)
        await state.set_state(QuizStates.HOME)
        await state.set_state(QuizStates.HOME)
    except Error as e:
        print(f"Database error: {e}")
        await callback.message.answer(f"{get_translation(lang, "db_connection_error")} {str(e)}")
    except Exception as e:
        print(f"Unexpected error: {e}")
        await callback.message.answer(f"{get_translation(lang, "error_occurred")} {str(e)}")