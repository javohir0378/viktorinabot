import asyncio
import logging
from datetime import datetime
from typing import Optional

from aiogram import Bot, Dispatcher, types
from aiogram.enums.dice_emoji import DiceEmoji
from aiogram.filters.callback_data import CallbackData
from aiogram.filters.command import Command
from aiogram.types import Update
from fastapi import FastAPI, Request

from data import config

logging.basicConfig(level=logging.INFO)
bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher()
app = FastAPI()

# Global context variables
dp["started_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")


# HANDLERS
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    await message.answer("Bot ishga tushdi! /test1 yoki /test2 buyruqlarini sinab ko'ring.")

@dp.message(Command("test1"))
async def cmd_test1(message: types.Message):
    await message.answer("Test 1")

@dp.message(Command("test2"))
async def cmd_test2(message: types.Message):
    await message.reply("Test 2")

@dp.message(Command("dice"))
async def cmd_dice(message: types.Message):
    await message.answer_dice(emoji=DiceEmoji.DICE)

@dp.message(Command("info"))
async def cmd_info(message: types.Message):
    started_at = dp.get("started_at", "Noma'lum vaqt")
    await message.answer(f"Bot {started_at} da ishga tushgan.")

# CALLBACK DATA
class QuizCallbackData(CallbackData, prefix="quiz"):
    action: str
    lang: int | None = None
def setup_handlers(dispatcher: Dispatcher) -> None:
    """HANDLERS"""
    from handlers import setup_routers

    dispatcher.include_router(setup_routers())


# FASTAPI EVENTS
@app.on_event("startup")
async def on_startup():
    logging.info("Webhookni o'rnatish...")
    await bot.set_webhook(url=config.WEBHOOK_URL)
    await bot.send_message(chat_id=1055073877,text="Salom")
    setup_handlers(dispatcher=dp)
    logging.info("Webhook o'rnatildi.")

@app.on_event("shutdown")
async def on_shutdown():
    logging.info("Webhookni o'chirish...")
    await bot.delete_webhook()
    logging.info("Webhook o'chirildi.")


# WEBHOOK ROUTE
@app.post(config.WEBHOOK_PATH)
async def telegram_webhook(request: Request):
    try:
        update = Update(**(await request.json()))
        await dp.feed_update(bot, update)
    except Exception as e:
        logging.error(f"Webhookda xatolik: {e}")
    return {"status": "OK"}
