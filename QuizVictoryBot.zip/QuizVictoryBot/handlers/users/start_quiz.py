import datetime

from aiogram import types, F, Router
from aiogram.enums import PollType
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, PollAnswer

from app import dp, bot

router = Router()


from aiogram import types
from aiogram.fsm.context import FSMContext
from db.db import db_connection, send_question, check_and_start_test


@router.callback_query(F.data.startswith("start_quiz:"))
async def start_quiz(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    test_uid = callback.data.split(":")[1]
    can_start = await check_and_start_test(user_id, test_uid)
    if not can_start:
        return
    await send_question(callback.message.chat.id,test_uid,1)
        #send_question_by_test_uid_and_question_id(callback.message.chat.id,test_uid,1))

