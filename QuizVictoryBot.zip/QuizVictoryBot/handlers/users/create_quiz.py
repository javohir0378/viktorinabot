from aiogram import  types, Router, F
from aiogram.filters.command import Command
from aiogram.fsm.context import FSMContext

from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, PollAnswer,
    BotCommand, Poll
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder

from app import dp
from db.db import db_connection
from keyboards.reply.keyboards import create_main_menu_keyboard
from lang.translate import get_translation, get_user_language
from states.test import QuizStates
from utils.generate_key import rand_string

router = Router()


@router.message(QuizStates.TITLE)
async def receive_title(message: Message, state: FSMContext):
    title = message.text
    user_id = message.from_user.id
    test_uid = rand_string(10)

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO tests (user_id, test_uid, title, description) VALUES (%s, %s, %s, %s)",
        (user_id, test_uid, title, None),
    )
    conn.commit()
    cursor.close()
    conn.close()

    await state.update_data(test_uid=test_uid)
    await message.answer("Sarlavha saqlandi. Endi tavsifni yuboring yoki /skip ni bosing.")
    await state.set_state(QuizStates.DESCRIPTION)


# Tavsifni o'tkazib yuborish
@router.message(Command("skip"), QuizStates.DESCRIPTION)
async def skip_description(message: Message, state: FSMContext):
    builder = ReplyKeyboardBuilder()
    builder.row(types.KeyboardButton(
        text="Test tuzish",
        request_poll=types.KeyboardButtonPollType(type="quiz"))
    )
    await message.answer("Tavsif o'tkazib yuborildi. Endi savolni yuboring.",reply_markup=builder.as_markup(resize_keyboard=True))

    await state.set_state(QuizStates.ADD_QUESTIONS)


# Tavsif olish
@router.message(QuizStates.DESCRIPTION)
async def receive_description(message: Message, state: FSMContext):
    description = message.text
    data = await state.get_data()
    test_uid = data.get("test_uid")

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE tests SET description = %s WHERE test_uid = %s", (description, test_uid))
    conn.commit()
    cursor.close()
    conn.close()

    builder = ReplyKeyboardBuilder()
    builder.row(types.KeyboardButton(
        text="Test tuzish",
        request_poll=types.KeyboardButtonPollType(type="quiz"))
    )
    await message.answer("Tavsif saqlandi. Endi savolni yuboring.",reply_markup=builder.as_markup(resize_keyboard=True))
    await state.set_state(QuizStates.ADD_QUESTIONS)

@router.message(Command('done'),QuizStates.ADD_QUESTIONS)
async def bot_help(message: types.Message,state:FSMContext):
    user_id = message.chat.id
    remove_keyboard = types.ReplyKeyboardRemove()
    await message.answer(text="Test yaratish yakunlandi.",reply_markup=remove_keyboard)
    lang = await get_user_language(user_id)
    welcome_text = get_translation(lang, "welcome")
    keyboard = create_main_menu_keyboard(lang)

    await message.answer(welcome_text, reply_markup=keyboard)

    await state.set_state(QuizStates.HOME)

def add_question(conn, test_uid, question, question_id):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO questions (test_uid, question_text, question_id) VALUES (%s, %s, %s)
    """, (test_uid, question, question_id))
    conn.commit()


# Funksiya: Bazaga javob qo'shish
def add_answer(conn, question_id, test_uid, text, is_correct, option_index):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO answers (question_id, test_uid, answer_text, is_correct, place_id)
        VALUES (%s, %s, %s, %s, %s)
    """, (question_id, test_uid, text, is_correct, option_index))
    conn.commit()


