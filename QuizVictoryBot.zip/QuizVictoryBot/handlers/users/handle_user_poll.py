from aiogram import types, F, Router
from aiogram.fsm.context import FSMContext

from app import dp
from db.db import db_connection
from filters import ChatPrivateFilter
from handlers.users.create_quiz import add_answer, add_question
from keyboards.reply.keyboards import create_main_menu_keyboard
from lang.translate import get_user_language
from states.test import QuizStates

router = Router()

@router.message(F.content_type == types.ContentType.POLL,QuizStates.ADD_QUESTIONS)
async def handle_user_poll(message: types.Message, state: FSMContext):
    poll = message.poll  # Message ichidagi poll obyektini olish
    user_id = message.chat.id
    question = poll.question  # Savol matni
    options = poll.options  # Variantlar
    correct_option_id = poll.correct_option_id  # To'g'ri javob indeksi

    data = await state.get_data()
    # Test UIDni olish
    test_uid =  data.get("test_uid")
    if not test_uid:
        await message.reply("Test ID majud emas.")
       # test_uid = rand_string(10)  # Tasodifiy 8 ta belgidan iborat UID yaratish
       # await state.update_data(test_uid=test_uid)
    # Bazaga ulanish
    conn = db_connection()
    if not conn:
        await message.reply("Ma'lumotlar bazasi bilan bog'lanishda xatolik yuz berdi.")
        return

    try:
        # Savol sonini aniqlash
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM questions WHERE test_uid = %s", (test_uid,))
        question_count = cursor.fetchone()[0]

        # Savol qo'shish
        question_id = question_count + 1
        add_question(conn, test_uid, question, question_id)

        # Variantlarni qo'shish
        for index, option in enumerate(options):
            is_correct = 1 if index == correct_option_id else 0
            add_answer(conn, question_id, test_uid, option.text, is_correct, index)

        # Foydalanuvchiga tasdiq xabari yuborish
        option_texts = ", ".join([option.text for option in options])
        response_text = f"Savol yaratildi!\nSavol: {question_id}. {question}\nVariantlar: {option_texts}"
        response_text+="\nBajarganingizdan keyin, test tuzishni yakunlash uchun shunchaki /done buyrugʻini yuboring."
        await message.reply(response_text)
    except Exception as e:
        await message.reply(f"Xatolik yuz berdi: {str(e)}.{question}")
    finally:
        conn.close()