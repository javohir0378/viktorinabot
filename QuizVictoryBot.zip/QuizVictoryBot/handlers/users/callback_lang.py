from aiogram import  types, Router, F
from aiogram.filters.command import Command
from aiogram.fsm.context import FSMContext

from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, PollAnswer,
    BotCommand, Poll
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder

from app import  QuizCallbackData
from db.db import db_connection
from lang.test import translations
from lang.translate import get_translation
from states.test import QuizStates

router = Router()



@router.callback_query(F.data == "change_language")
async def my_lang(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchini bazada qidirish
    cursor.execute("SELECT lang FROM users WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()
    lang = user[0]
    cursor.close()
    conn.close()

    # Tarjima
    lang_key = str(lang)
    uz = get_translation(1, "lang")
    en = get_translation(2, "lang")
    ru = get_translation(3, "lang")
    welcome_text = translations[lang_key]["welcome"]
    lang_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=uz,
                              callback_data=QuizCallbackData(action="set_language", lang=1).pack())],
        [InlineKeyboardButton(text=en,
                              callback_data=QuizCallbackData(action="set_language", lang=2).pack())],
        [InlineKeyboardButton(text=ru,
                              callback_data=QuizCallbackData(action="set_language", lang=3).pack())],
    ])

    await callback.message.answer(welcome_text, reply_markup=lang_keyboard)
    await state.set_state(QuizStates.HOME)

@router.callback_query(QuizCallbackData.filter(F.action == "set_language"))
async def set_language(callback: CallbackQuery, callback_data: QuizCallbackData, state: FSMContext):
    lang = callback_data.lang
    user_id = callback.from_user.id

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET lang = %s WHERE user_id = %s", (lang, user_id))
    conn.commit()
    cursor.close()
    conn.close()

    # Til tanlangandan keyin
    lang_selected_message = translations[str(lang)]["language_selected"]
    home_message = translations[str(lang)]["home"]

    # Inline keyboard
    home_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Viktorina yaratish", callback_data="create_quiz")],
        [InlineKeyboardButton(text="Tilni o'zgartirish", callback_data="change_language")],
    ])

    await callback.message.edit_text(lang_selected_message)
    await callback.message.answer(home_message, reply_markup=home_keyboard)
