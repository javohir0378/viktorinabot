from aiogram import Router, types, F
from aiogram.enums import ChatType
from aiogram.filters import CommandStart
from aiogram.enums.parse_mode import ParseMode
from aiogram.client.session.middlewares.request_logging import logger
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app import dp
from db.db import db_connection, check_and_start_test
from filters import IsBotAdminFilter, ChatPrivateFilter
from handlers.users.create_quiz import add_question, add_answer
from lang.translate import get_translation, get_user_language
from loader import  bot
from keyboards.inline.buttons import star_keyboard
from data.config import ADMINS
from states.test import QuizStates

router = Router()

from keyboards.reply.keyboards import create_main_menu_keyboard
import re
def escape_markdown_v2(text: str) -> str:
    """
    Telegram MarkdownV2 uchun maxsus belgilarni qochiradi.
    """
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return re.sub(f"([{re.escape(escape_chars)}])", r"\\\1", text)

@router.message(CommandStart(), ChatPrivateFilter(chat_type=["private"]))
async def do_start(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    args = message.text.split(" ")[1:] if " " in message.text else []
    test_uid = args[0] if args else None

    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchini bazada qidirish
    cursor.execute("SELECT lang FROM users WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()

    if message.chat.type == ChatType.PRIVATE:
        if not user:
            lang = 1  # Default language: Uzbek
            cursor.execute(
                """
                INSERT INTO users (user_id, fname, lname, username, ref, refbalance, balance, lang, subcr, verified)
                VALUES (%s, %s, %s, %s, 0, 0, 0, %s, 0, 0)
                """,
                (
                    user_id,
                    message.from_user.first_name,
                    message.from_user.last_name or "",
                    message.from_user.username or "",
                    lang,
                ),
            )
            conn.commit()
        else:
            lang = user[0]

        # Deep linkdan test UIDni qayta ishlash
        if test_uid:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM tests WHERE test_uid = %s", (test_uid,))
            quiz = cursor.fetchone()

            if quiz:
                can_start = await check_and_start_test(user_id, test_uid)
                if not can_start:
                    return
                # Foydalanuvchi tilini olish
                lang = await get_user_language(user_id)

                # Tarjimalarni olish
                quiz_title = get_translation(lang, "quiz_title")  # "📌"
                quiz_uid = get_translation(lang, "quiz_uid")  # "🆔 Test UID:"
                quiz_description = get_translation(lang, "quiz_description")  # "✏️ Tavsif:"
                no_description = get_translation(lang, "no_description")  # "Tavsif yo'q"
                start_quiz = get_translation(lang, "start_quiz")  # "Testni Boshlash"

                # Inline tugma yaratish
                builder = InlineKeyboardBuilder()
                builder.button(
                    text=start_quiz,
                    callback_data=f"start_quiz:{test_uid}"
                )

                # Ma'lumotlarni ko'rsatish
                title = escape_markdown_v2(quiz['title'])
                description = escape_markdown_v2(quiz['description'] or no_description)
                response = (
                    f"{quiz_title} *{title}*\n"
                    f"{quiz_uid} `{quiz['test_uid']}`\n"
                    f"{quiz_description} {description}"
                )
                await message.answer(response, reply_markup=builder.as_markup(), parse_mode="Markdown")
            else:
                await message.answer("Ushbu test mavjud emas. Yangi test yaratishingiz mumkin.")
        else:
            welcome_text = get_translation(lang, "welcome")
            keyboard = create_main_menu_keyboard(lang)

            await message.answer(welcome_text, reply_markup=keyboard)
            await state.set_state(QuizStates.HOME)
    else:
        words = message.text.split()
        if len(words) == 1:
            bot_info = await bot.get_me()
            builder = InlineKeyboardBuilder()
            builder.row(types.InlineKeyboardButton(
                text="Go to DM",
                url=f"t.me/{bot_info.username}?start=anything")
            )
            await message.reply(
                "No quiz selected. Please DM the bot to create one.",
                reply_markup=builder.as_markup()
            )


@router.callback_query(F.data == "create_quiz")
async def create_quiz(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("Yangi viktorina yaratamiz. Sarlavha yuboring:")
    await state.set_state(QuizStates.TITLE)

@router.callback_query(F.data == "my_victory",QuizStates.HOME)
async def my_victory(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id

    conn = db_connection()
    if not conn:
        await callback.message.reply(get_translation(1, "db_connection_error"))  # Default Uzbek tilida xabar
        return

    try:
        cursor = conn.cursor(dictionary=True)

        # Foydalanuvchi yaratgan testlarni olish
        cursor.execute("SELECT * FROM tests WHERE user_id = %s", (user_id,))
        quizzes = cursor.fetchall()

        # Foydalanuvchi tilini olish
        lang = await get_user_language(user_id)  # Tildan foydalanish
        lang_key = str(lang)

        # Tarjimalarni olish
        your_quizzes_list = get_translation(lang, "your_quizzes_list")  # "Siz yaratgan viktorinalar ro'yxati:"
        quiz_title = get_translation(lang, "quiz_title")  # "📌"
        quiz_uid = get_translation(lang, "quiz_uid")  # "🆔 Test UID:"
        quiz_description = get_translation(lang, "quiz_description")  # "✏️ Tavsif:"
        question_count = get_translation(lang, "question_count")  # "🧐 Savollar soni:"
        no_quizzes_created = get_translation(lang,
                                             "no_quizzes_created")  # "Siz hali hech qanday viktorina yaratmagansiz."
        error_occurred = get_translation(lang, "error_occurred")  # "Xatolik yuz berdi:"
        no_description = get_translation(lang, "no_description")  # "Tavsif yo'q"

        if quizzes:
            response = your_quizzes_list + "\n\n"  # Tarjima qilingan ro'yxat boshi
            for quiz in quizzes:
                # Har bir test uchun savollar sonini olish
                cursor.execute("SELECT COUNT(*) AS question_count FROM questions WHERE test_uid = %s",
                               (quiz['test_uid'],))
                question_count_value = cursor.fetchone()["question_count"]

                # Ma'lumotlarni qochirish va javob yaratish
                title = escape_markdown_v2(quiz['title'])
                description = escape_markdown_v2(quiz['description'] or no_description)
                response += (
                    f"{quiz_title} *{title}*\n"
                    f"{quiz_uid} `{quiz['test_uid']}`\n"
                    f"{quiz_description} {description}\n"
                    f"{question_count} {question_count_value}\n\n"
                )
        else:
            response = no_quizzes_created

        await callback.message.reply(response, parse_mode="Markdown")
    except Exception as e:
        await callback.message.reply(f"{error_occurred}: {str(e)}")
    finally:
        conn.close()
