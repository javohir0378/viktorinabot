from aiogram import Router, types
from aiogram.filters.command import Command
from aiogram.fsm.context import FSMContext

from data.config import ADMINS
from filters import IsBotAdminFilter
from states.test import QuizStates

router = Router()


@router.message(Command('cancel'))
async def bot_help(message: types.Message,state:FSMContext):

    await message.answer(text="Jarayon bekor qilindi")
    await state.set_state(QuizStates.HOME)