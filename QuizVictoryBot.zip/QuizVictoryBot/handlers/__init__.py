from aiogram import Router

from filters import ChatPrivateFilter, IsBotAdminFilter


from test import ADMINS


def setup_routers() -> Router:
    from .users import admin, start, help,create_quiz,handle_user_poll,start_quiz,handle_user_answer,callback_lang,cancel
    from .errors import error_handler

    router = Router()

    # Agar kerak bo'lsa, o'z filteringizni o'rnating
    start.router.message.filter(ChatPrivateFilter(chat_type=["private"]))
    create_quiz.router.message.filter(ChatPrivateFilter(chat_type=["private"]))
   # handle_user_poll.router.message.filter(ChatPrivateFilter(chat_type=["private"]))
  #  help.router.message.filter(IsBotAdminFilter(ADMINS))

    router.include_routers(admin.router, start.router, help.router, error_handler.router,create_quiz.router,handle_user_poll.router,start_quiz.router,handle_user_answer.router,callback_lang.router,cancel.router)

    return router
