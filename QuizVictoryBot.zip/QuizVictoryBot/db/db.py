import mysql.connector
from aiogram.enums import PollType
from mysql.connector import Error
import asyncio
from datetime import datetime
from app import bot


def db_connection():
    """
    MySQL database connection function.
    Returns:
        conn: Database connection object or None if failed.
    """
    try:
        conn = mysql.connector.connect(
            host="185.253.217.251",
            user="yculjjxo_admin",
            password="sadiso0307",
            database="yculjjxo_quizbot",
            autocommit=True  # Avtomatik commit qilishni yoqish (zaruratga qarab sozlang)
        )
        if conn.is_connected():
            print("Database connection successful!")
        return conn
    except Error as err:
        if err.errno == 1045:
            print("Error: Access denied - Incorrect username or password")
        elif err.errno == 1049:
            print("Error: Unknown database specified")
        elif err.errno == 2003:
            print("Error: Cannot connect to the database server")
        elif err.errno == 2005:
            print("Error: Unknown MySQL server host")
        else:
            print(f"Error: {err}")
        return None


async def send_question(user_id, test_uid, question_id):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Jami savollar sonini olish
        query = """
            SELECT COUNT(*) 
            FROM questions 
            WHERE test_uid = %s
        """
        cursor.execute(query, (test_uid,))
        total_questions = cursor.fetchone()[0]

        # Agar barcha savollar tugagan bo'lsa
        if question_id > total_questions:
            await bot.send_message(chat_id=user_id, text="Tabriklaymiz! Testni yakunladingiz.")
            # Test yakunlanganda natijani yuborish
            await send_results(user_id, test_uid)

            return

        # Savolni bazadan olish
        query = """
            SELECT question_text 
            FROM questions 
            WHERE test_uid = %s AND question_id = %s
        """
        cursor.execute(query, (test_uid, question_id))
        question_row = cursor.fetchone()

        if question_row:
            question_text = question_row[0]

            # Javob variantlarini olish
            options = []
            correct_option_index = None
            query = """
                SELECT answer_text, is_correct 
                FROM answers 
                WHERE test_uid = %s AND question_id = %s 
                ORDER BY place_id
            """
            cursor.execute(query, (test_uid, question_id))
            answers = cursor.fetchall()

            for index, (answer_text, is_correct) in enumerate(answers):
                options.append(answer_text)
                if is_correct == 1:
                    correct_option_index = index

            # Savolni foydalanuvchiga yuborish
            poll_message = await bot.send_poll(
                chat_id=user_id,
                question=question_text,
                options=options,
                type="quiz",
                correct_option_id=correct_option_index,
                is_anonymous=False,
                open_period=15
            )

            # Poll ma'lumotlarini saqlash
            query = """
                INSERT INTO polls (user_id, poll_id, question_id, test_uid, sent_time, correct_option_id)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (user_id, poll_message.poll.id, question_id, test_uid, datetime.now(), correct_option_index))
            connection.commit()

            # 15 soniya kutib, javobni tekshirish
            await asyncio.sleep(15)
            query = """
                SELECT COUNT(*) 
                FROM user_answers 
                WHERE poll_id = %s AND user_id = %s
            """
            cursor.execute(query, (poll_message.poll.id, user_id))
            answer_count = cursor.fetchone()[0]

            if answer_count == 0:
                # Agar javob bo'lmasa, skipped sifatida saqlash
                query = """
                    INSERT INTO user_answers (user_id, poll_id, test_uid, question_id, answer_text, is_correct, skipped, answered_at, selected_option_index)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(query, (
                    user_id,
                    poll_message.poll.id,
                    test_uid,
                    question_id,
                    "Tashlab ketildi",  # Javob matni
                    0,                  # To'g'ri emas
                    1,                  # Skipped
                    None,               # Javob vaqti yo'q
                    None                # Variant tanlanmagan
                ))
                connection.commit()

                # Keyingi savolga o'tish
                await send_question(user_id, test_uid, question_id + 1)
            else:
                print(f"Foydalanuvchi {user_id} javob berdi. Poll ID: {poll_message.poll.id}")

        else:
            # Agar savol topilmasa
            await bot.send_message(chat_id=user_id, text=f"Xato: Savol topilmadi. ID: {question_id}")

    except Exception as e:
        print(f"Xato: {e}")


async def send_results(user_id, test_uid):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Foydalanuvchining javoblarini olish
        query = """
            SELECT is_correct, skipped 
            FROM user_answers 
            WHERE user_id = %s AND test_uid = %s
        """
        cursor.execute(query, (user_id, test_uid))
        user_answers = cursor.fetchall()

        correct_answers = 0
        wrong_answers = 0
        skipped_questions = 0

        # Javoblarni tahlil qilish
        for is_correct, skipped in user_answers:
            if skipped == 1:
                skipped_questions += 1
            elif is_correct == 1:
                correct_answers += 1
            elif is_correct == 0:
                wrong_answers += 1

        # Test natijalarini yuborish
        result_text = f"To'g'ri javoblar: {correct_answers}\n"
        result_text += f"Xato javoblar: {wrong_answers}\n"
        result_text += f"Tashlab ketilgan savollar: {skipped_questions}"
        await save_test_results(user_id, test_uid, correct_answers, wrong_answers, skipped_questions)

        await bot.send_message(chat_id=user_id, text=result_text)

    except Exception as e:
        print(f"Xato: {e}")



async def check_and_start_test(user_id: int, test_uid: str):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Testning holatini tekshirish
        query = """
            SELECT completed 
            FROM test_results 
            WHERE user_id = %s AND test_uid = %s
        """
        cursor.execute(query, (user_id, test_uid))
        result = cursor.fetchone()

        if result and result[0] == 1:  # Test tugatilgan bo'lsa
            await bot.send_message(
                chat_id=user_id,
                text="Ushbu testni avval yechib bo'lgansiz. Boshqa testni tanlang."
            )
            return False
        elif result is None:  # Agar yozuv bo'lmasa, testni boshlash uchun yangi yozuv yaratiladi
            await bot.send_message(
                chat_id=user_id,
                text="Test Boshlandi"
            )

        # Testni boshlash
        return True

    except Exception as e:
        print(f"Xato: {e}")
        return False

async def save_test_results(user_id, test_uid, correct_answers, wrong_answers, skipped_questions):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Umumiy ballni hisoblash (masalan, to'g'ri javoblar soni asosida)
        total_score = correct_answers

        # Test natijalarini saqlash
        query = """
            INSERT INTO test_results (user_id, test_uid, correct_answers, wrong_answers, skipped_questions, total_score, test_completed_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (user_id, test_uid, correct_answers, wrong_answers, skipped_questions, total_score, datetime.now()))
        connection.commit()

    except Exception as e:
        print(f"Xato: {e}")


def get_current_question_index(user_id):
    """Foydalanuvchining hozirgi savol indeksini qaytaradi."""
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)  # Dictionary cursorni o'rnating
    try:
        query = "SELECT currentQuestionIndex FROM users WHERE user_id = %s"
        cursor.execute(query, (user_id,))
        row = cursor.fetchone()
        return row['currentQuestionIndex'] if row else None
    finally:
        cursor.close()
        conn.close()
def increment_question_index(user_id):
    """Foydalanuvchi uchun savol indeksini 1 ga oshiradi."""
    conn = db_connection()
    cursor = conn.cursor()

    try:
        query = "UPDATE users SET currentQuestionIndex = currentQuestionIndex + 1 WHERE user_id = %s"
        cursor.execute(query, (user_id,))
        conn.commit()

    finally:
       cursor.close()
       conn.close()


def set_question_index(user_id, index):
    """Foydalanuvchi uchun savol indeksini belgilaydi."""
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        query = "UPDATE users SET currentQuestionIndex = %s WHERE user_id = %s"
        cursor.execute(query, (index, user_id))
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def save_poll_metadata(user_id, poll_id, question_id, sent_time):
    # Ma'lumotlar bazasiga yozish
    connection = db_connection()
    cursor = connection.cursor()
    query = """
        INSERT INTO polls (user_id, poll_id, question_id, sent_time)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (user_id, poll_id, question_id, sent_time))
    connection.commit()
    connection.close()

def is_answer_received(user_id, poll_id):
    # Poll javobining mavjudligini tekshirish
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT COUNT(*) FROM user_answers WHERE poll_id = %s AND user_id = %s"
    cursor.execute(query, (poll_id, user_id))
    result = cursor.fetchone()
    connection.close()
    return result[0] > 0

def get_question_by_id(test_uid, question_id):
    # Savolni olish uchun ma'lumotlar bazasi so'rovi
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM questions WHERE test_uid = %s AND question_id = %s"
    cursor.execute(query, (test_uid, question_id))
    question = cursor.fetchone()
    connection.close()
    return question

def get_answers_by_question_id(test_uid, question_id):
    # Javob variantlarini olish
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM answers WHERE test_uid = %s AND question_id = %s ORDER BY place_id"
    cursor.execute(query, (test_uid, question_id))
    answers = cursor.fetchall()
    connection.close()
    return answers
