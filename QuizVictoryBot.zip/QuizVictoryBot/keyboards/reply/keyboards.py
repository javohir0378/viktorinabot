from aiogram import types
from lang.translate import get_translation

def create_main_menu_keyboard(lang: int) -> types.InlineKeyboardMarkup:
    """
    Asosiy menyu uchun InlineKeyboard yaratadi.
    :param lang: Foydalanuvchining til identifikatori (1 - Uzbek, 2 - Russian, 3 - English)
    :return: InlineKeyboardMarkup obyekt
    """
    buttons = [
        [
            types.InlineKeyboardButton(text=get_translation(lang, "create_quiz"), callback_data="create_quiz"),
            types.InlineKeyboardButton(text=get_translation(lang, "list_quizzes"), callback_data="my_victory"),
        ],
        [
            types.InlineKeyboardButton(text=get_translation(lang, "balance"), callback_data="balance"),
            types.InlineKeyboardButton(text=get_translation(lang, "language"), callback_data="change_language"),
        ],
        [
            types.InlineKeyboardButton(text=get_translation(lang, "confirm"), callback_data="num_finish"),
        ]
    ]
    return types.InlineKeyboardMarkup(inline_keyboard=buttons)
