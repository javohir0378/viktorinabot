from aiogram import Bot, Dispatcher, F, types
from aiogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.filters import Command
from aiogram import Router
import asyncio
from data import config

# Bot tokeningizni o'rnating
BOT_TOKEN = "5742010455"

# Bot va Dispatcher
bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher()

# Admin ID ro'yxati
ADMINS = [5742010455, 1055073877]  # Adminlarning ID'larini yozing

# Buyurtma berish tugmasi
def get_order_button():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Buyurtma Berish", callback_data="order")]
        ]
    )

# Adminlar uchun buyurtma ma'lumotlarini to'plash
class OrderData:
    def __init__(self):
        self.narxi = None
        self.hajmi = None
        self.kargo = None
        self.muddat = None
        self.dp = None
        self.photos = []  # Rasmlar saqlanishi uchun qo'shimcha maydon
order_data = {}
# Adminlarni tekshirish va maxsus xabar yuborish
@dp.message(Command("start"))
async def start_command(message: Message):
    admin_id = message.from_user.id

    # Agar admin bo'lsa
    if admin_id in ADMINS:
        await message.answer(
            "🔧 Botga xush kelibsiz!\n\n"
            "Siz admin sifatida botni boshqarishingiz mumkin.\n\n"
            "Quyidagi tugmalarni tanlab, buyurtmalarni boshqarishingiz mumkin.",
            reply_markup=get_order_button()  # Buyurtma berish tugmasi
        )
    else:
        await message.answer("Salom! Siz botni foydalanuvchi sifatida ishlatishingiz mumkin.")

# Buyurtma ma'lumotlarini to'plash jarayoni
async def ask_for_data(admin_id: int, step: str):
    if step == "narxi":
        await bot.send_message(admin_id, "🛒 *Buyurtma tafsilotlari:* \n\n📌 *Narxini kiriting:*")
    elif step == "hajmi":
        await bot.send_message(admin_id, "📦 *Hajmini kiriting:*")
    elif step == "kargo":
        await bot.send_message(admin_id, "✈️ *Kargo tafsilotlarini kiriting:*")
    elif step == "muddat":
        await bot.send_message(admin_id, "⏳ *Yetkazib berish muddatini kiriting:*")
    elif step == "dp":
        await bot.send_message(admin_id, "📎 *Qo'shimcha ma'lumotlarni kiriting:*")
    elif step == "photo":
        await bot.send_message(admin_id, "📸 *Iltimos, bir yoki bir nechta rasm yuboring:*")

# Ma'lumotlarni olish va botga yuborish
@dp.callback_query(F.data == "order")
async def handle_order_button(callback_query: types.CallbackQuery):
    admin_id = callback_query.from_user.id

    if admin_id not in order_data:
        order_data[admin_id] = OrderData()

    await ask_for_data(admin_id, "narxi")  # Buyurtma narxini so'rash
    await callback_query.answer("Iltimos, buyurtma tafsilotlarini kiritishni boshlang.", show_alert=True)

# Admin ma'lumotlarni yuborganida, ularni saqlash va keyingi savolni yuborish
@dp.message(F.text)
async def process_order_input(message: Message):
    admin_id = message.from_user.id

    # Agar admin buyurtma ma'lumotlarini kiritishni boshlagan bo'lsa
    if admin_id in order_data:
        data = order_data[admin_id]

        # Admin narxini kiritgan bo'lsa
        if data.narxi is None:
            data.narxi = message.text
            await ask_for_data(admin_id, "hajmi")
        # Admin hajmi kiritgan bo'lsa
        elif data.hajmi is None:
            data.hajmi = message.text
            await ask_for_data(admin_id, "kargo")
        # Admin kargo ma'lumotini kiritgan bo'lsa
        elif data.kargo is None:
            data.kargo = message.text
            await ask_for_data(admin_id, "muddat")
        # Admin muddatni kiritgan bo'lsa
        elif data.muddat is None:
            data.muddat = message.text
            await ask_for_data(admin_id, "dp")
        # Admin qo'shimcha ma'lumotni kiritgan bo'lsa
        elif data.dp is None:
            data.dp = message.text
            await ask_for_data(admin_id, "photo")  # Rasmlarni so'rash

# Rasmlar qabul qilish
def get_confirm_button():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Rasdiqlash", callback_data="confirm_order")]
        ]
    )


@dp.message(F.photo)
async def handle_photo(message: Message):
    admin_id = message.from_user.id

    if admin_id in order_data:
        data = order_data[admin_id]

        # Rasmlarni saqlaymiz
        photo_id = message.photo[-1].file_id  # Eng yuqori sifatli rasmni olish
        data.photos.append(photo_id)

        # Agar bir nechta rasm yuborilgan bo'lsa
        if len(data.photos) == 1:
            await message.answer("Rasm qabul qilindi. Boshqa rasm yuborishni istasangiz, yuboring.")
        else:
            await message.answer("Yana bir rasm qabul qilindi.")

        # Agar barcha rasm yuborilgan bo'lsa, keyingi savolga o'tish
        if len(data.photos) >= 1:
            await message.answer("Rasmlar to'liq kiritildi. Tasdiqlashni boshlaymiz.")
            formatted_caption = (
                f"🛒 *Buyurtma tafsilotlari:*\n"
                f"📌 *Narxi:* {data.narxi}\n"
                f"📦 *Hajmi:* {data.hajmi}\n"
                f"✈️ *Kargo:* {data.kargo}\n"
                f"⏳ *Yetkazib berish muddati:* {data.muddat}\n"
                f"📎 *Qo'shimcha ma'lumot:* {data.dp}"
            )
            # Adminni tasdiqlash uchun yuborish
            await bot.send_message(admin_id, f"Buyurtma tasdiqlash uchun quyidagi ma'lumotlar:\n\n{formatted_caption}")
            await bot.send_message(admin_id, "Ma'lumotlar to'g'ri ekanligini tasdiqlaysizmi?", reply_markup=get_confirm_button())

# Buyurtma tasdiqlash tugmasi
@dp.callback_query(F.data == "confirm_order")
async def confirm_order(callback_query: types.CallbackQuery):
    admin_id = callback_query.from_user.id
    if admin_id in order_data:
        data = order_data[admin_id]
        formatted_caption = (
            f"🛒 *Buyurtma tafsilotlari:*\n"
            f"📌 *Narxi:* {data.narxi}\n"
            f"📦 *Hajmi:* {data.hajmi}\n"
            f"✈️ *Kargo:* {data.kargo}\n"
            f"⏳ *Yetkazib berish muddati:* {data.muddat}\n"
            f"📎 *Qo'shimcha ma'lumot:* {data.dp}"
        )
        # Adminlarga buyurtma ma'lumotlarini yuborish
        for admin_id in ADMINS:
            media = [
                types.InputMediaPhoto(media=photo_id) for photo_id in data.photos
            ]
            await bot.send_media_group(
                chat_id=admin_id,
                media=media
            )
            await bot.send_message(admin_id, f"🛒 *Yangi buyurtma tasdiqlandi:*\n\n{formatted_caption}",
                                   parse_mode="Markdown")


        # Buyurtma jarayonini tugatish
        await bot.send_message(admin_id, "Buyurtma tasdiqlandi va adminlarga yuborildi.")
        # Buyurtma ma'lumotlarini tozalash
        del order_data[admin_id]

    await callback_query.answer()

# Routerni sozlaymiz
router = Router()
dp.include_router(router)


# Asosiy ishga tushirish funksiyasi
async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
