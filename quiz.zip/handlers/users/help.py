from aiogram import Router, types
from aiogram.filters.command import Command

from data.config import ADMINS
from filters import IsBotAdminFilter

router = Router()


@router.message(Command('help'),IsBotAdminFilter(ADMINS))
async def bot_help(message: types.Message):
    text = ("Buyruqlar: ",
            "/start - Botni ishga tushirish",
            "/help - Yordam")
    await message.answer(text="\n".join(text))
