import random

from aiogram.types import PollAnswer
from datetime import datetime
import asyncio
from app import dp,bot
from aiogram import types, Router
from aiogram.fsm.context import FSMContext
from db.db import db_connection, send_results, check_random_question
from handlers.users.start_quiz import send_question

router = Router()



@router.poll_answer()
async def handle_poll_answer(poll_answer: PollAnswer):
    try:
        user_id = poll_answer.user.id
        poll_id = poll_answer.poll_id
        selected_option = poll_answer.option_ids[0] if poll_answer.option_ids else None

        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Poll ID asosida savol ID va test UID ni topish
        query = """
            SELECT question_id, test_uid 
            FROM polls 
            WHERE poll_id = %s
        """
        cursor.execute(query, (poll_id,))
        poll_row = cursor.fetchone()

        if not poll_row:
            print(f"Xato: Poll ID topilmadi. Poll ID: {poll_id}")
            return

        question_id, test_uid = poll_row

        # Javobni baholash
        query = """
            SELECT correct_option_id 
            FROM polls 
            WHERE poll_id = %s
        """
        cursor.execute(query, (poll_id,))
        correct_option_id = cursor.fetchone()[0]

        is_correct = 1 if selected_option == correct_option_id else 0
        skipped = 0 if selected_option is not None else 1
        answered_at = datetime.now() if selected_option is not None else None

        # Javobni saqlash
        query = """
            INSERT INTO user_answers (user_id, poll_id, test_uid, question_id, answer_text, is_correct, skipped, answered_at, selected_option_index)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        answer_text = "Tashlab ketildi" if skipped else "Javob berildi"
        cursor.execute(query, (user_id, poll_id, test_uid, question_id, answer_text, is_correct, skipped, answered_at, selected_option))
        connection.commit()

        # `random_question` qiymatini aniqlash
        random_question = await check_random_question(test_uid)  # Bu funksiya testning `random` bo'lishini aniqlaydi

        # Savollarni aniqlash
        query = """
            SELECT question_id 
            FROM questions 
            WHERE test_uid = %s
        """
        cursor.execute(query, (test_uid,))
        all_questions = [row[0] for row in cursor.fetchall()]

        query = """
            SELECT question_id 
            FROM polls 
            WHERE user_id = %s AND test_uid = %s
        """
        cursor.execute(query, (user_id, test_uid))
        sent_questions = [row[0] for row in cursor.fetchall()]

        remaining_questions = list(set(all_questions) - set(sent_questions))

        if not remaining_questions:
            # Agar barcha savollar tugagan bo'lsa, natijani yuboring
            await bot.send_message(chat_id=user_id, text="Tabriklaymiz! Test yakunlandi.")
            await send_results(user_id, test_uid)
            await asyncio.sleep(2)
            # Test yakunlanganda `completed` ni yangilash va natijalarni yuborish
            query = """
                                        UPDATE test_results 
                                        SET completed = 1 
                                        WHERE user_id = %s AND test_uid = %s
                                    """
            cursor.execute(query, (user_id, test_uid))
            connection.commit()
        else:
            # Keyingi savolni tanlash
            if random_question:
                next_question_id = random.choice(remaining_questions)
            else:
                next_question_id = min(remaining_questions)

            # Keyingi savolni yuborish
            await send_question(user_id, test_uid, next_question_id)

    except Exception as e:
        print(f"Xato: {e}")
