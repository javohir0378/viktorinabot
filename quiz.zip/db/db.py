import random

import mysql.connector
from aiogram.enums import PollType
from mysql.connector import Error
import asyncio
from datetime import datetime
from app import bot


def db_connection():
    """
    MySQL database connection function.
    Returns:
        conn: Database connection object or None if failed.
    """
    try:
        conn = mysql.connector.connect(
            host="185.253.217.251",
            user="yculjjxo_admin",
            password="sadiso0307",
            database="yculjjxo_quizbot",
            autocommit=True  # Avtomatik commit qilishni yoqish (zaruratga qarab sozlang)
        )
        if conn.is_connected():
            print("Database connection successful!")
        return conn
    except Error as err:
        if err.errno == 1045:
            print("Error: Access denied - Incorrect username or password")
        elif err.errno == 1049:
            print("Error: Unknown database specified")
        elif err.errno == 2003:
            print("Error: Cannot connect to the database server")
        elif err.errno == 2005:
            print("Error: Unknown MySQL server host")
        else:
            print(f"Error: {err}")
        return None


async def send_question(user_id, test_uid, question_id):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        cursor.execute("SELECT * FROM tests WHERE test_uid = %s", (test_uid,))
        quiz = cursor.fetchone()

        # Savol va media ma'lumotlarini olish
        query = """
            SELECT question_text, addition, media_type 
            FROM questions 
            WHERE test_uid = %s AND question_id = %s
        """
        cursor.execute(query, (test_uid, question_id))
        question_row = cursor.fetchone()

        if question_row:
            question_text, media, media_type = question_row

            # Javob variantlarini olish
            options = []
            query = """
                SELECT answer_text, is_correct 
                FROM answers 
                WHERE test_uid = %s AND question_id = %s 
                ORDER BY place_id
            """
            cursor.execute(query, (test_uid, question_id))
            answers = cursor.fetchall()

            for index, (answer_text, is_correct) in enumerate(answers):
                options.append((answer_text, is_correct))

            # Random variantlarni aralashtirish
            random_options = await check_random_options(test_uid)
            if random_options:
                random.shuffle(options)

            correct_option_index = next((index for index, (_, is_correct) in enumerate(options) if is_correct == 1), None)
            options_text = [answer_text for answer_text, _ in options]
            time_quiz = get_time_quiz_by_test_uid(test_uid)
            # Media bilan savolni foydalanuvchiga yuborish
            if media_type == "photo":
                await bot.send_photo(chat_id=user_id, photo=media, caption=question_text)
            elif media_type == "video":
                await bot.send_video(chat_id=user_id, video=media, caption=question_text)
            elif media_type == "document":
                await bot.send_document(chat_id=user_id, document=media, caption=question_text)
            else:
                await bot.send_message(chat_id=user_id, text=question_text)

            # Javob variantlarini yuborish
            poll_message = await bot.send_poll(
                chat_id=user_id,
                question=question_text,
                options=options_text,
                type="quiz",
                correct_option_id=correct_option_index,
                is_anonymous=False,
                open_period=time_quiz
            )

            # Poll ma'lumotlarini saqlash
            query = """
                INSERT INTO polls (user_id, poll_id, question_id, test_uid, sent_time, correct_option_id)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (user_id, poll_message.poll.id, question_id, test_uid, datetime.now(), correct_option_index))
            connection.commit()

            # 15 soniya kutib, javobni tekshirish
            await asyncio.sleep(time_quiz)

            query = """
                SELECT COUNT(*) 
                FROM user_answers 
                WHERE poll_id = %s AND user_id = %s
            """
            cursor.execute(query, (poll_message.poll.id, user_id))
            answer_count = cursor.fetchone()[0]

            if answer_count == 0:
                # Agar javob bo'lmasa, skipped sifatida saqlash
                query = """
                    INSERT INTO user_answers (user_id, poll_id, test_uid, question_id, answer_text, is_correct, skipped, answered_at, selected_option_index)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(query, (
                    user_id,
                    poll_message.poll.id,
                    test_uid,
                    question_id,
                    "Tashlab ketildi",  # Javob matni
                    0,                  # To'g'ri emas
                    1,                  # Skipped
                    None,               # Javob vaqti yo'q
                    None                # Variant tanlanmagan
                ))
                connection.commit()

                # Keyingi savolni yuborish
                await send_next_question(user_id, test_uid)

        else:
            await bot.send_message(chat_id=user_id, text=f"Xato: Savol topilmadi. ID: {question_id}")

    except Exception as e:
        print(f"Xato: {e}")
    finally:
        connection.close()

async def check_random_options(test_uid):
    # Test UID bo'yicha random variantlarni tekshirish
    # False qaytaradi (agar randomizatsiya yo'q bo'lsa)
    return True


async def send_next_question(user_id, test_uid):
    """
    Keyingi savolni yuborish funksiyasi.
    """
    connection = None
    try:
        connection = db_connection()
        cursor = connection.cursor()

        # Testdagi barcha savollarni olish
        query = "SELECT question_id FROM questions WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        all_questions = [row[0] for row in cursor.fetchall()]

        if not all_questions:
            await bot.send_message(chat_id=user_id, text="Test uchun savollar topilmadi.")
            return

        # Yuborilgan savollarni aniqlash
        query = "SELECT question_id FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        sent_questions = [row[0] for row in cursor.fetchall()]

        # Qolgan savollarni aniqlash
        remaining_questions = list(set(all_questions) - set(sent_questions))
        if not remaining_questions:
            await bot.send_message(chat_id=user_id, text="Tabriklaymiz! Testni yakunladingiz.")
            await send_results(user_id, test_uid)
            return

        # Random yoki tartib bo‘yicha keyingi savolni tanlash
        random_question = await check_random_question(test_uid)
        question_id = random.choice(remaining_questions) if random_question else min(remaining_questions)

        await send_question(user_id, test_uid, question_id)

    except Exception as e:
        print(f"Xato: {e}")
    finally:
        if connection:
            connection.close()
def get_time_quiz_by_test_uid(test_uid):
    try:
        # Ulash
        connection = db_connection()
        cursor = connection.cursor()

        # SELECT so'rovini bajarish
        query = "SELECT time_quiz FROM tests WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))

        # Natijani olish
        result = cursor.fetchone()
        if result:
            return result[0]  # `time_quiz` qiymati
        else:
            return None  # test_uid topilmadi
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
async def check_random_question(test_uid):
    connection = db_connection()
    if not connection:
        return False

    cursor = connection.cursor()
    query = """
        SELECT random_question 
        FROM tests 
        WHERE test_uid = %s
    """
    cursor.execute(query, (test_uid,))
    result = cursor.fetchone()
    connection.close()

    return result[0] == 1 if result else False

async def check_random_options(test_uid):
    """
    Random variantlar tartibini tekshiradi.
    :param test_uid: Test UID
    :return: True agar random bo'lsa, aks holda False
    """
    connection = None
    try:
        connection = db_connection()
        cursor = connection.cursor()

        query = "SELECT random_options FROM tests WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        result = cursor.fetchone()
        return result[0] if result else False
    except Exception as e:
        print(f"Xato: {e}")
        return False
    finally:
        if connection:
            connection.close()

async def send_results(user_id, test_uid):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Foydalanuvchining javoblarini olish
        query = """
            SELECT is_correct, skipped 
            FROM user_answers 
            WHERE user_id = %s AND test_uid = %s
        """
        cursor.execute(query, (user_id, test_uid))
        user_answers = cursor.fetchall()

        correct_answers = 0
        wrong_answers = 0
        skipped_questions = 0

        # Javoblarni tahlil qilish
        for is_correct, skipped in user_answers:
            if skipped == 1:
                skipped_questions += 1
            elif is_correct == 1:
                correct_answers += 1
            elif is_correct == 0:
                wrong_answers += 1

        # Test natijalarini yuborish
        result_text = f"To'g'ri javoblar: {correct_answers}\n"
        result_text += f"Xato javoblar: {wrong_answers}\n"
        result_text += f"Tashlab ketilgan savollar: {skipped_questions}"
        await save_test_results(user_id, test_uid, correct_answers, wrong_answers, skipped_questions)

        await bot.send_message(chat_id=user_id, text=result_text)

    except Exception as e:
        print(f"Xato: {e}")



async def check_and_start_test(user_id, test_uid):
    """
    Testni boshlashga ruxsatni tekshirish funksiyasi.
    """
    connection = None
    try:
        connection = db_connection()
        cursor = connection.cursor()

        # Avval bu testni boshlaganmi yoki yo'qmi tekshiramiz
        query = "SELECT COUNT(*) FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        count = cursor.fetchone()[0]

        if count > 0:
            await bot.send_message(chat_id=user_id, text="Siz bu testni avval boshlagansiz.")
            return False

        return True
    except Exception as e:
        print(f"Xato: {e}")
        return False
    finally:
        if connection:
            connection.close()

async def save_test_results(user_id, test_uid, correct_answers, wrong_answers, skipped_questions):
    try:
        connection = db_connection()
        if not connection:
            return

        cursor = connection.cursor()

        # Umumiy ballni hisoblash (masalan, to'g'ri javoblar soni asosida)
        total_score = correct_answers

        # Test natijalarini saqlash
        query = """
            INSERT INTO test_results (user_id, test_uid, correct_answers, wrong_answers, skipped_questions, total_score, test_completed_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (user_id, test_uid, correct_answers, wrong_answers, skipped_questions, total_score, datetime.now()))
        connection.commit()

    except Exception as e:
        print(f"Xato: {e}")


def get_current_question_index(user_id):
    """Foydalanuvchining hozirgi savol indeksini qaytaradi."""
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)  # Dictionary cursorni o'rnating
    try:
        query = "SELECT currentQuestionIndex FROM users WHERE user_id = %s"
        cursor.execute(query, (user_id,))
        row = cursor.fetchone()
        return row['currentQuestionIndex'] if row else None
    finally:
        cursor.close()
        conn.close()
def increment_question_index(user_id):
    """Foydalanuvchi uchun savol indeksini 1 ga oshiradi."""
    conn = db_connection()
    cursor = conn.cursor()

    try:
        query = "UPDATE users SET currentQuestionIndex = currentQuestionIndex + 1 WHERE user_id = %s"
        cursor.execute(query, (user_id,))
        conn.commit()

    finally:
       cursor.close()
       conn.close()


def set_question_index(user_id, index):
    """Foydalanuvchi uchun savol indeksini belgilaydi."""
    conn = db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        query = "UPDATE users SET currentQuestionIndex = %s WHERE user_id = %s"
        cursor.execute(query, (index, user_id))
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def save_poll_metadata(user_id, poll_id, question_id, sent_time):
    # Ma'lumotlar bazasiga yozish
    connection = db_connection()
    cursor = connection.cursor()
    query = """
        INSERT INTO polls (user_id, poll_id, question_id, sent_time)
        VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (user_id, poll_id, question_id, sent_time))
    connection.commit()
    connection.close()

def is_answer_received(user_id, poll_id):
    # Poll javobining mavjudligini tekshirish
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT COUNT(*) FROM user_answers WHERE poll_id = %s AND user_id = %s"
    cursor.execute(query, (poll_id, user_id))
    result = cursor.fetchone()
    connection.close()
    return result[0] > 0

def get_question_by_id(test_uid, question_id):
    # Savolni olish uchun ma'lumotlar bazasi so'rovi
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM questions WHERE test_uid = %s AND question_id = %s"
    cursor.execute(query, (test_uid, question_id))
    question = cursor.fetchone()
    connection.close()
    return question

def get_answers_by_question_id(test_uid, question_id):
    # Javob variantlarini olish
    connection = db_connection()
    cursor = connection.cursor()
    query = "SELECT * FROM answers WHERE test_uid = %s AND question_id = %s ORDER BY place_id"
    cursor.execute(query, (test_uid, question_id))
    answers = cursor.fetchall()
    connection.close()
    return answers
def add_question(conn, test_uid, question, question_id):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO questions (test_uid, question_text, question_id) VALUES (%s, %s, %s)
    """, (test_uid, question, question_id))
    conn.commit()


# Funksiya: Bazaga javob qo'shish
def add_answer(conn, question_id, test_uid, text, is_correct, option_index):
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO answers (question_id, test_uid, answer_text, is_correct, place_id)
        VALUES (%s, %s, %s, %s, %s)
    """, (question_id, test_uid, text, is_correct, option_index))
    conn.commit()


