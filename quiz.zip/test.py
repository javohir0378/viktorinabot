from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, InputMediaPhoto
from aiogram import Router
import asyncio

from data import config

# Tokenni o'rnating
BOT_TOKEN = config.BOT_TOKEN

# Bot va dispatcherni yaratamiz
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Admin ID ro'yxati
ADMINS = [5742010455, 1055073877]  # Adminlarning Telegram ID'larini yozing


# Guruh xabarlarini qayta ishlash uchun handler
async def handle_admin_message(message: Message):
    # Faqat adminlardan kelgan xabarlarni qayta ishlash
    if message.from_user.id in ADMINS:
        try:
            if message.media_group_id:  # Bir nechta rasmlar (media group)
                # Rasmlar guruhini olamiz
                photos = [message.photo[-1].file_id]
            elif message.photo:  # Faqat bitta rasm bo'lsa
                photos = [message.photo[-1].file_id]
            else:
                photos = []

            if not photos:
                # Agar rasm yo'q bo'lsa, foydalanuvchiga xabar yuboriladi
                await bot.send_message(
                    chat_id=message.chat.id,
                    text="❌ Xabar rasmni o‘z ichiga olishi kerak.",
                )
                return

            # Xabarni vergul bo'yicha ajratamiz
            if message.caption:
                parts = message.caption.split(",")
            else:
                parts = []

            # Parametrlarni aniqlaymiz
            if len(parts) == 4:  # 4 qismni kutamiz: Narxi, Hajmi, Kargo, Yetkazib berish muddati
                narxi = parts[0].strip()
                hajmi = parts[1].strip()
                kargo = parts[2].strip()
                muddat = parts[3].strip()

                # Formatlangan matn
                formatted_text = (
                    f"🛒 *Buyurtma tafsilotlari:*\n"
                    f"📌 *Narxi:* {narxi}\n"
                    f"📦 *Hajmi:* {hajmi}\n"
                    f"✈️ *Kargo:* {kargo}\n"
                    f"⏳ *Yetkazib berish muddati:* {muddat}"
                )

                # Rasmlarni bitta xabarda yuboramiz
                media = []
                for i, photo_id in enumerate(photos):
                    caption = formatted_text if i == len(photos) - 1 else None
                    media.append(InputMediaPhoto(media=photo_id, caption=caption,caption_entities=message.caption_entities, parse_mode="Markdown"))

                # Rasmlar guruhini yuborish
                await bot.send_media_group(chat_id=message.chat.id, media=media)
                await message
                # Asl xabarni o'chirish
                await bot.delete_message(chat_id=message.chat.id, message_id=message.message_id)
            else:
                # Xabar noto'g'ri formatda yuborilgan
                await bot.send_message(
                    chat_id=message.chat.id,
                    text="❌ Xabar noto'g'ri formatda yuborilgan. Iltimos, quyidagicha yuboring:\n"
                         "`25$, 54, Yo'q, 15-20 kun`",
                    parse_mode="Markdown"
                )
        except Exception as e:
            print(f"Xatolik yuz berdi: {e}")


# Router qo'shish
router = Router()
router.message.register(handle_admin_message, F.photo | F.media_group_id)

dp.include_router(router)


# Asosiy ishga tushirish funksiyasi
async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
