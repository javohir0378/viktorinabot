from aiogram import types
from lang.translate import get_translation

def create_main_menu_keyboard(lang: int) -> types.InlineKeyboardMarkup:
    """
    Asosiy menyu uchun InlineKeyboard yaratadi.
    :param lang: Foydalanuvchining til identifikatori (1 - Uzbek, 2 - Russian, 3 - English)
    :return: InlineKeyboardMarkup obyekt
    """
    buttons = [
        [
            types.InlineKeyboardButton(text=get_translation(lang, "create_quiz"), callback_data="create_quiz"),
            types.InlineKeyboardButton(text=get_translation(lang, "list_quizzes"), callback_data="my_victory"),
        ],
        [
            types.InlineKeyboardButton(text=get_translation(lang, "balance"), callback_data="balance"),
            types.InlineKeyboardButton(text=get_translation(lang, "language"), callback_data="change_language"),
        ],
        [
            types.InlineKeyboardButton(text=get_translation(lang, "confirm"), callback_data="num_finish"),
        ]
    ]
    return types.InlineKeyboardMarkup(inline_keyboard=buttons)


def create_time_menu_keyboard(lang: int) -> types.InlineKeyboardMarkup:
    """
    Vaqt tanlash uchun InlineKeyboard yaratadi.
    :param lang: Foydalanuvchining til identifikatori (1 - Uzbek, 2 - Russian, 3 - English)
    :return: InlineKeyboardMarkup obyekt
    """
    buttons = [
        [
            types.InlineKeyboardButton(text=get_translation(lang, "time_10_seconds"), callback_data="time:10"),
            types.InlineKeyboardButton(text=get_translation(lang, "time_15_seconds"), callback_data="time:15"),
            types.InlineKeyboardButton(text=get_translation(lang, "time_30_seconds"), callback_data="time:30"),
        ],
        [
            types.InlineKeyboardButton(text=get_translation(lang, "time_1_minute"), callback_data="time:60"),
            types.InlineKeyboardButton(text=get_translation(lang, "time_2_minutes"), callback_data="time:120"),
            types.InlineKeyboardButton(text=get_translation(lang, "time_3_minutes"), callback_data="time:180"),
        ]
    ]
    return types.InlineKeyboardMarkup(inline_keyboard=buttons)


def create_shuffle_menu_keyboard(lang: int) -> types.InlineKeyboardMarkup:
    """
    Vaqt tanlash uchun InlineKeyboard yaratadi.
    :param lang: Foydalanuvchining til identifikatori (1 - Uzbek, 2 - Russian, 3 - English)
    :return: InlineKeyboardMarkup obyekt
    """
    buttons = [
        [
            types.InlineKeyboardButton(text=get_translation(lang, "quiz_random"), callback_data="quiz_random"),
            types.InlineKeyboardButton(text=get_translation(lang, "answer_random"), callback_data="answer_random"),
        ],
        [
            types.InlineKeyboardButton(text=get_translation(lang, "all_random"), callback_data="all_random"),
            types.InlineKeyboardButton(text=get_translation(lang, "no_random"), callback_data="no_random"),
        ]
    ]
    return types.InlineKeyboardMarkup(inline_keyboard=buttons)
