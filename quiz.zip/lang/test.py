import os
import json

# Joriy papka yo'lini olish
current_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(current_dir, "translations.json")

# JSON faylni ochish
with open(file_path, "r", encoding="utf-8") as f:
    translations = json.load(f)
print("Looking for file at:", file_path)
