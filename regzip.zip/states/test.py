from aiogram.filters.state import StatesGroup, State


class QuizStates(StatesGroup):
    HOME = State()
    LANGUAGE = State()
    TITLE = State()
    DESCRIPTION = State()
    BANNER_VICTORY = State()
    TIME_QUIZ = State()
    SHUFFLE = State()
    PRIZE = State()
    ADD_QUESTIONS = State()
    QUIZ_PLAYING = State()

class DepositStates(StatesGroup):
    enter_amount = State()
    wait_receipt = State()

class AdminState(StatesGroup):
    are_you_sure = State()
    ask_ad_content = State()
