import json

from db.db import db_connection

with open("lang/translations.json", "r", encoding="utf-8") as f:
    translations = json.load(f)
def get_translation(lang: int, key: str) -> str:
    lang_key = str(lang)
    return translations.get(lang_key, {}).get(key, key)
async def get_user_language(user_id):
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT lang FROM users WHERE user_id = %s", (user_id,))
    lang = cursor.fetchone()
    cursor.close()
    conn.close()
    return lang[0] if lang else 1  # Default language: Uzbek
