import json
import logging
import asyncio
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import KeyboardButtonPollType, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, InputTextMessageContent, InlineQueryResultArticle
from aiogram.utils import deep_linking
from aiogram.enums import ChatType
from aiogram.utils.keyboard import InlineKeyboardBuilder

from quizzer import Quiz

logging.basicConfig(level=logging.INFO)

# Bot initialization
bot = Bot(token="1508781046:AAF8jUlfAdZBYU6kXGI9w_1iBuAfMj3Ss0o")
dp = Dispatcher()

# Placeholder dictionaries to store quizzes and their owners
quizzes_database = {}  # Store quizzes by user ID
quizzes_owners = {}  # Map quiz ID to owner ID


import mysql.connector
def db_connection():
    try:
        conn = mysql.connector.connect(
            host="185.253.217.251",
            user="yculjjxo_admin",
            password="sadiso0307",
            database="yculjjxo_quizbot",
        )
        return conn
    except mysql.connector.Error as err:
        print(f"Xato: {err}")
        return None


# Quiz class to handle quiz data
def save_quiz_to_db(quiz):
    connection = db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute(
            """
            INSERT INTO quizzes (quiz_id, question, options, correct_option_id, owner_id)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                question=VALUES(question),
                options=VALUES(options),
                correct_option_id=VALUES(correct_option_id);
            """,
            (quiz.quiz_id, quiz.question, json.dumps(quiz.options), quiz.correct_option_id, quiz.owner_id)
        )
        connection.commit()
    finally:
        cursor.close()
        connection.close()

def get_user_quizzes(owner_id):
    connection = db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM quizzes WHERE owner_id = %s", (owner_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()

def get_quiz_from_db(quiz_id):
    dbconnection = db_connection()
    cursor = dbconnection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM quizzes WHERE quiz_id = %s", (quiz_id,))
    quiz_data = cursor.fetchone()
    cursor.close()
    dbconnection.close()
    return quiz_data

def update_quiz_winners(quiz_id, winners):
    connection = db_connection()
    cursor = connection.cursor()
    try:
        cursor.execute(
            "UPDATE quizzes SET winners = %s WHERE quiz_id = %s",
            (json.dumps(winners), quiz_id)
        )
        connection.commit()
    finally:
        cursor.close()
        connection.close()



# Handle poll answers
@dp.poll_answer()
async def handle_poll_answer(quiz_answer: types.PollAnswer):
    connection = db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM quizzes WHERE quiz_id = %s", (quiz_answer.poll_id,))
        quiz = cursor.fetchone()
        if not quiz:
            logging.error(f"Viktorina topilmadi: poll_id={quiz_answer.poll_id}")
            return

        winners = json.loads(quiz['winners'])
        if quiz['correct_option_id'] == quiz_answer.option_ids[0]:
            winners.append(quiz_answer.user.id)
            update_quiz_winners(quiz_answer.poll_id, winners)

            if len(winners) == 2:
                await bot.stop_poll(chat_id=quiz['chat_id'], message_id=quiz['message_id'])
    finally:
        cursor.close()
        connection.close()
# Handle closed polls
@dp.poll()
async def just_poll_answer(active_quiz: types.Poll):
    dbconnection =db_connection()
    cursor = dbconnection.cursor(dictionary=True)

    # `poll_id` asosida quizni topish
    cursor.execute("SELECT * FROM quizzes WHERE quiz_id = %s", (active_quiz.id,))
    quiz_data = cursor.fetchone()

    if not quiz_data:
        logging.error(f"Cannot find the quiz owner with poll_id={active_quiz.id}")
        cursor.close()
        dbconnection.close()
        return

    # G'oliblarni JSON formatidan yuklash
    winners = json.loads(quiz_data["winners"]) if quiz_data["winners"] else []

    # G'oliblarni aniqlash va tabriklash
    congrats_text = []
    for winner_id in winners:
        chat_member_info = await bot.get_chat_member(quiz_data["chat_id"], winner_id)
        congrats_text.append(chat_member_info.user.get_mention(as_html=True))

    # Xabar yuborish
    await bot.send_message(
        quiz_data["chat_id"],
        f"Quiz finished! Here are the winners:\n\n" + "\n".join(congrats_text),
        parse_mode="HTML"
    )

    # Quizni bazadan o'chirish
    cursor.execute("DELETE FROM quizzes WHERE id = %s", (quiz_data["id"],))
    dbconnection.commit()

    cursor.close()
    dbconnection.close()

# Start command for private chat
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    if message.chat.type == ChatType.PRIVATE:
        poll_keyboard = ReplyKeyboardMarkup(
            keyboard=[
                [types.KeyboardButton(
                    text="Create a Quiz",
                    request_poll=KeyboardButtonPollType(type="quiz")
                )],
                [types.KeyboardButton(text="Cancel")]
            ],
            resize_keyboard=True
        )
        await message.answer(
            "Press the button below to create a quiz!", reply_markup=poll_keyboard
        )
    else:
        words = message.text.split()
        if len(words) == 1:
            bot_info = await bot.get_me()
            keyboard = InlineKeyboardMarkup()
            move_to_dm_button = InlineKeyboardButton(
                text="Go to DM",
                url=f"t.me/{bot_info.username}?start=anything"
            )
            keyboard.add(move_to_dm_button)
            await message.reply(
                "No quiz selected. Please DM the bot to create one.",
                reply_markup=keyboard
            )
        else:
            quiz_id = words[1]
            quiz_data = get_quiz_from_db(quiz_id)

            if not quiz_data:
                await message.reply("Invalid or expired quiz. Please create a new one.")
                return

            # SQL-dan olingan ma'lumotlarni o'quvchi poll sifatida yuborish
            msg = await bot.send_poll(
                chat_id=message.chat.id,
                question=quiz_data["question"],
                is_anonymous=False,
                options=json.loads(quiz_data["options"]),
                type="quiz",
                correct_option_id=quiz_data["correct_option_id"]
            )

            # Yangilangan poll ID va xabar ID ni bazaga qayta saqlash
            dbconnection = db_connection()
            cursor = dbconnection.cursor()
            cursor.execute(
                "UPDATE quizzes SET quiz_id = %s, chat_id = %s, message_id = %s WHERE id = %s",
                (msg.poll.id, message.chat.id, msg.message_id, quiz_data["id"])
            )
            dbconnection.commit()
            cursor.close()
            dbconnection.close()

# Cancel action handler
@dp.message(lambda msg: msg.text == "Cancel")
async def action_cancel(message: types.Message):
    await message.answer("Action canceled. Use /start to start again.", reply_markup=types.ReplyKeyboardRemove())

# Handling incoming quiz polls
@dp.message(F.content_type == types.ContentType.POLL)
async def msg_with_poll(message: types.Message):
    if not quizzes_database.get(str(message.from_user.id)):
        quizzes_database[str(message.from_user.id)] = []
    if message.poll.type != "quiz":
        await message.reply("Only quiz-type polls are accepted!")
        return
    quiz = Quiz(
        quiz_id=message.poll.id,
        question=message.poll.question,
        options=[o.text for o in message.poll.options],
        correct_option_id=message.poll.correct_option_id,
        owner_id=message.from_user.id
    )
    # Debug log to verify the quiz object
    print(vars(quiz))

    save_quiz_to_db(quiz)
    await message.reply(f"Quiz saved. Total quizzes: {message.poll.id}")

# Handle inline query for quiz sharing
@dp.inline_query()
async def inline_query(query: types.InlineQuery):
    results = []
    user_quizzes = quizzes_database.get(str(query.from_user.id))
    if user_quizzes:
        for quiz in user_quizzes:
            #keyboard = InlineKeyboardMarkup()
            builder = InlineKeyboardBuilder()
            builder.row(types.InlineKeyboardButton(
                text="GitHub", url=await deep_linking.get_startgroup_link(quiz.quiz_id))
            )
            start_quiz_button = InlineKeyboardButton(
                text="Send to Group", url=await deep_linking.get_startgroup_link(quiz.quiz_id)
            )
          #  keyboard.add(start_quiz_button)
            results.append(
                InlineQueryResultArticle(
                    id=quiz.quiz_id,
                    title=quiz.question,
                    input_message_content=InputTextMessageContent(
                        message_text="Click below to send the quiz to the group."
                    ),
                    reply_markup=builder.as_markup()
                )
            )
    await query.answer(
        results=results, switch_pm_text="Create a quiz", switch_pm_parameter="_", cache_time=120, is_personal=True
    )

# Start polling
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())