from aiogram import Router, types, F
from aiogram.enums import ChatType
from aiogram.filters import CommandStart, StateFilter
from aiogram.enums.parse_mode import ParseMode
from aiogram.client.session.middlewares.request_logging import logger
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineQueryResultArticle, InputTextMessageContent, \
    InlineQueryResultCachedPhoto
from aiogram.utils import deep_linking
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.filters.command import Command, CommandObject
from app import dp
from db.db import db_connection, check_and_start_test, get_user_currency
from db.function import handle_balance
from filters import IsBotAdminFilter, ChatPrivateFilter
from aiogram.utils.markdown import markdown_decoration as emd

from handlers.users.balans import handle_balance_query
from lang.translate import get_translation, get_user_language
from loader import  bot
from keyboards.inline.buttons import star_keyboard
from data.config import ADMINS
from states.test import QuizStates, DepositStates
from aiogram import Dispatcher, filters

from utils.Payme import Payme

router = Router()

from keyboards.reply.keyboards import create_main_menu_keyboard, create_currency_keyboard, create_balance_keyboard
import re
def escape_markdown_v2(text):
    """
    Telegram MarkdownV2 formatidagi xabarlarni formatlashda qochirilishi kerak bo'lgan maxsus belgilarni qochiradi.
    """
    return re.sub(r'([_*\[\]()~`>#+\-=|{}.!])', r'\\\1', text)


@router.message(CommandStart())
async def do_start(message: types.Message, command: CommandObject, state: FSMContext):
    user_id = message.from_user.id
    test_uid = command.args  # Deep linking parameter

    # Guruhda testni deep link orqali boshlash
    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchini bazada qidirish
    cursor.execute("SELECT lang FROM users WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()

    if message.chat.type == ChatType.PRIVATE:
        if not user:
            lang = 1  # Default language: Uzbek
            cursor.execute(
                """
                INSERT INTO users (user_id, fname, lname, username, ref, refbalance, balance, lang, subcr, verified)
                VALUES (%s, %s, %s, %s, 0, 0, 0, %s, 0, 0)
                """,
                (
                    user_id,
                    message.from_user.first_name,
                    message.from_user.last_name or "",
                    message.from_user.username or "",
                    lang,
                ),
            )
            conn.commit()
        else:
            lang = user[0]

        # Deep linkdan test UIDni qayta ishlash
        if test_uid:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM tests WHERE test_uid = %s", (test_uid,))
            quiz = cursor.fetchone()

            if quiz:
                can_start = await check_and_start_test(user_id, test_uid)
                if not can_start:
                    return
                # Foydalanuvchi tilini olish
                lang = await get_user_language(user_id)

                # Tarjimalarni olish
                quiz_title = get_translation(lang, "quiz_title")  # "📌"
                quiz_uid = get_translation(lang, "quiz_uid")  # "🆔 Test UID:"
                quiz_description = get_translation(lang, "quiz_description")  # "✏️ Tavsif:"
                no_description = get_translation(lang, "no_description")  # "Tavsif yo'q"
                start_quiz = get_translation(lang, "start_quiz")  # "Testni Boshlash"

                # Inline tugma yaratish
                builder = InlineKeyboardBuilder()
                builder.button(
                    text=start_quiz,
                    callback_data=f"start_quiz:{test_uid}"
                )

                # Ma'lumotlarni ko'rsatish
                title = escape_markdown_v2(quiz['title'])
                description = escape_markdown_v2(quiz['description'] or no_description)
                response = (
                    f"{quiz_title} *{title}*\n"
                    f"{quiz_uid} `{quiz['test_uid']}`\n"
                    f"{quiz_description} {description}"
                )
                await message.answer(response, reply_markup=builder.as_markup(), parse_mode="Markdown")
            else:
                await message.answer("Ushbu test mavjud emas. Yangi test yaratishingiz mumkin.")
        else:
            welcome_text = get_translation(lang, "welcome")
            keyboard = create_main_menu_keyboard(lang)

            await message.answer(welcome_text, reply_markup=keyboard)
            await state.set_state(QuizStates.HOME)
    else:
        words = message.text.split()
        if len(words) == 1:
            bot_info = await bot.get_me()
            builder = InlineKeyboardBuilder()
            builder.row(types.InlineKeyboardButton(
                text="Go to DM",
                url=f"t.me/{bot_info.username}?start=anything")
            )
            await message.reply(
                "No quiz selected. Please DM the bot to create one.",
                reply_markup=builder.as_markup()
            )

@router.callback_query(F.data == "create_quiz")
async def create_quiz(callback: CallbackQuery, state: FSMContext):
    user_id = callback.message.chat.id
    lang = await get_user_language(user_id)
    await callback.message.answer(get_translation(lang, "state_create_quiz"))
    await state.set_state(QuizStates.TITLE)

@router.callback_query(F.data == "back")
async def back(callback: CallbackQuery, state: FSMContext):
    user_id = callback.message.chat.id
    lang = await get_user_language(user_id)
    home_message = get_translation(lang,"home")
    welcome_text = get_translation(lang, "welcome")
    # Inline keyboard
    keyboard = create_main_menu_keyboard(lang)
    await callback.message.edit_text(home_message + "\n" + welcome_text, reply_markup=keyboard)

@router.callback_query(F.data == "change_currency")
async def change_currency(callback: CallbackQuery, state: FSMContext):
    """
    Foydalanuvchi valyutani o'zgartirishi uchun tugmalar.
    """
    lang = await get_user_language(callback.from_user.id)

    # Valyuta tugmalari
    currency_buttons = [
        [types.InlineKeyboardButton(text="🇺🇿 So'm", callback_data="currency_1")],
        [types.InlineKeyboardButton(text="🇷🇺 Rubl", callback_data="currency_2")],
        [types.InlineKeyboardButton(text="🇺🇸 Dollar", callback_data="currency_3")],
    ]
    currency_menu = types.InlineKeyboardMarkup(inline_keyboard=currency_buttons)

    await callback.message.edit_text(get_translation(lang, "choose_currency"), reply_markup=currency_menu)
    await callback.answer()


@router.callback_query(F.data.startswith("currency_"))
async def set_currency(callback: CallbackQuery, state: FSMContext):
    """
    Foydalanuvchi tanlagan valyutani saqlash.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)

    # Callback data'dan valyutani olish
    currency = int(callback.data.split("_")[1])

    # Valyutani yangilash
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET currency = %s WHERE user_id = %s", (currency, user_id))
    conn.commit()
    cursor.close()
    conn.close()

    # Xabarni to‘g‘ridan-to‘g‘ri edit qilish
    new_text = f"✅ {get_translation(lang, 'currency_updated')}\n\n"
    await callback.message.edit_text(new_text)

    # Balansni qayta ko‘rsatish
    await handle_balance(user_id, callback.message)



@router.callback_query(F.data == "start_quiz")
async def start_quiz(callback_query: types.CallbackQuery):
    test_uid = callback_query.data.split(":")[1]
    # Testni boshlash kodlari
    await callback_query.message.answer(f"Test {test_uid} boshlandi!")
from aiogram import types
from aiogram.filters import CommandObject


@router.message(Command(re.compile(r"view_([a-zA-Z0-9_]+)")))
async def view_quiz_details(message: types.Message, command: CommandObject):
    # UIDni ajratib olish
    test_uid = command.regexp_match.group(1)

    # Ma'lumotlar bazasiga ulanish
    # (Sizning ma'lumotlar bazasi ulanish kodini bu yerga qo'shing)
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT title, description, 
               (SELECT COUNT(*) FROM questions WHERE test_uid = %s) AS question_count
        FROM tests WHERE test_uid = %s
        """,
        (test_uid, test_uid),
    )
    quiz = cursor.fetchone()
    conn.close()

    # Agar viktorina topilmasa
    if not quiz:
        await message.reply("Bu viktorina mavjud emas.")
        return

    title, description, question_count = quiz
    description = description or "Tavsif yo‘q"

    response = (
        f"📌  {escape_markdown_v2(title)}\n"
        f"🆔 Test UID: /view_{test_uid}\n"
        f"✏️ Tavsif:  {escape_markdown_v2(description)}\n"
        f"🧐 Savollar soni:  {question_count}\n\n"
    )
    # Inline tugmalarni yaratish
    buttons = [
        [types.InlineKeyboardButton(text="Testni boshlash", callback_data=f"start_quiz:{test_uid}")],
       # [types.InlineKeyboardButton(text="Guruhda testni boshlash", callback_data=f"group_{test_uid}")],
        [types.InlineKeyboardButton(text="Testni ulashish", switch_inline_query=test_uid)],
        [types.InlineKeyboardButton(text="Viktorina Statistikasi", callback_data=f"stats_{test_uid}")],
    ]

    keyboard = types.InlineKeyboardMarkup(inline_keyboard=buttons)
    await message.reply(response, reply_markup=keyboard)

@router.callback_query(F.data.startswith("group_"))
async def start_quiz_in_group(callback_query: types.CallbackQuery):
    test_uid = callback_query.data.split("_")[1]
    bot_info = await bot.get_me()

    # Deep link yaratish
    url = await deep_linking.create_startgroup_link(bot, payload=test_uid)

    buttons = [
        [types.InlineKeyboardButton(text="Testni boshlash", url=url)]
    ]
    keyboard = types.InlineKeyboardMarkup(inline_keyboard=buttons)

    await callback_query.message.answer(
        f"Guruhda testni boshlash uchun quyidagi tugmani bosing:\n\n👉 {url}",
        reply_markup=keyboard
    )


# Statistikani ko'rsatish
@router.callback_query(F.data.startswith("stats_"))
async def view_quiz_stats(callback_query: types.CallbackQuery):
    test_uid = callback_query.data.split("_")[1]
    # Statistikani olish va ko‘rsatish
    await callback_query.message.answer(f"{test_uid} testining statistikasi hozircha mavjud emas.")
PAGE_SIZE = 10  # Bir sahifada ko'rsatiladigan viktorinalar soni

@router.callback_query(F.data.startswith("my_victory_"))
async def list_user_quizzes(callback: types.CallbackQuery):
    user_id = callback.from_user.id

    # Joriy sahifani aniqlash
    try:
        page = int(callback.data.split("_")[-1])  # Sahifa raqamini olish
    except ValueError:
        page = 1  # Noto'g'ri callback_data bo'lsa, default 1-sahifa
    start_idx = (page - 1) * PAGE_SIZE
    end_idx = start_idx + PAGE_SIZE

    conn = db_connection()
    if not conn:
        await callback.message.reply("Bazaga ulanishda xatolik yuz berdi.")
        return

    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT title, test_uid, description,
                   (SELECT COUNT(*) FROM questions WHERE test_uid=tests.test_uid) AS question_count
            FROM tests
            WHERE user_id = %s
        """, (user_id,))
        quizzes = cursor.fetchall()
    finally:
        conn.close()

    if not quizzes:
        await callback.message.reply("Siz hali hech qanday viktorina yaratmagansiz.")
        return

    # Jami sahifalar sonini hisoblash
    total_pages = (len(quizzes) + PAGE_SIZE - 1) // PAGE_SIZE

    # Joriy sahifadagi viktorinalar
    current_quizzes = quizzes[start_idx:end_idx]

    # Javob xabarini yaratish
    response = f"Siz yaratgan viktorinalar ro'yxati (Sahifa {page}/{total_pages}):\n\n"
    for quiz in current_quizzes:
        title, test_uid, description, question_count = quiz
        description = description or "Tavsif yo‘q"
        response += (
            f"📌 {escape_markdown_v2(title)}\n"
            f"🆔 Test UID: /view_{escape_markdown_v2(test_uid)}\n"
            f"✏️ Tavsif: {escape_markdown_v2(description)}\n"
            f"🧐 Savollar soni: {question_count}\n\n"
        )

    # Tugmalarni yaratish
    builder = InlineKeyboardBuilder()
    if page > 1:
        builder.add(InlineKeyboardButton(
            text="◀️ Oldingi", callback_data=f"my_victory_{page - 1}"
        ))
    if page < total_pages:
        builder.add(InlineKeyboardButton(
            text="Keyingi ▶️", callback_data=f"my_victory_{page + 1}"
        ))

    # Xabarni yangilash
    await callback.message.edit_text(
        text=response,
        reply_markup=builder.as_markup()
    )


from aiogram import types
from aiogram.types import InlineQueryResultPhoto, InlineKeyboardButton
from aiogram.utils.deep_linking import create_start_link, create_startgroup_link
from aiogram.utils.keyboard import InlineKeyboardBuilder


@router.inline_query()
async def inline_query_handler(inline_query: types.InlineQuery):
    test_uid = inline_query.query.strip()
    if not test_uid:
        return

    results = []
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT title, description, banner_url, 
               (SELECT COUNT(*) FROM questions WHERE test_uid = %s) AS question_count 
        FROM tests 
        WHERE test_uid = %s
        """,
        (test_uid, test_uid),
    )
    quiz = cursor.fetchone()
    conn.close()

    # Print natijalarni tekshirish
    print(f"Test UID: {test_uid}")
    print(f"Quiz natijasi: {quiz}")

    if not quiz:
        print("Test topilmadi.")
        return  # Agar test topilmasa, hech narsa yubormaslik

    title, description, banner_url, question_count = quiz
    description = description or "Tavsif yo‘q"

    # Xabarni tayyorlash
    response = f"📌 {title}\n✏️ Tavsif: {description}\n🧐 Savollar soni: {question_count}"

    # Rasmning o'lchamlarini qo'shish (agar kerak bo'lsa)
    photo_width = 320  # Rasm kengligi (o'zingizga moslashtiring)
    photo_height = 240  # Rasm balandligi (o'zingizga moslashtiring)

    # Inline keyboardni yaratish
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(
        text="Testni boshlash",
        url=await create_start_link(bot, payload=test_uid)
    ))
   # builder.row(InlineKeyboardButton(
     #   text="Guruhda testni boshlash",
    #    url=await create_startgroup_link(bot, payload=test_uid)
   # ))
    builder.row(InlineKeyboardButton(
        text="Testni ulashish", switch_inline_query=test_uid)
    )

    # InlineQueryResultPhoto uchun natijani yaratish
    results.append(
        InlineQueryResultArticle(
            id=str(test_uid),
            thumbnail_url="https://i.imgur.com/clBZF2Y.jpg",
            title=title,
            description=description+f"\n🧐 Savollar soni: {question_count}",
            input_message_content=types.InputTextMessageContent(message_text=response),
           # photo_file_id="AgACAgIAAxkBAAIC1GdbAXsBI3w2s6la61SPtgEzf28kAAKe6jEbTPfZSg3aLlkylQs6AQADAgADeQADNgQ",   # Asosiy rasm URL
            #caption=response,       # Inline query orqali yuboriladigan xabar
            reply_markup=builder.as_markup()
        )
    )

    # Natijani qaytarish
    print(f"Inline query natijasi: {results}")  # Natijalarni tekshirish
    await inline_query.answer(
        results=results,
        cache_time=120,
        is_personal=True  # Har bir foydalanuvchi uchun moslashtirish
    )




async def send_long_message(chat_id, text):
    max_length = 4096
    while len(text) > max_length:
        await bot.send_message(chat_id, text[:max_length])
        text = text[max_length:]
    await bot.send_message(chat_id, text)
