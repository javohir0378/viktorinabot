from aiogram import  types, Router, F
from aiogram.filters.command import Command
from aiogram.fsm.context import FSMContext

from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, PollAnswer,
    BotCommand, Poll
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder
from utils.generate_key import rand_string
from app import dp
from db.db import db_connection
from keyboards.reply.keyboards import create_main_menu_keyboard, create_time_menu_keyboard, create_shuffle_menu_keyboard
from lang.translate import get_translation, get_user_language
from states.test import QuizStates

router = Router()


@router.message(QuizStates.TITLE)
async def receive_title(message: Message, state: FSMContext):
    title = message.text
    user_id = message.from_user.id
    test_uid = rand_string(10)
    lang = await get_user_language(user_id)
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO tests (user_id, test_uid, title, description) VALUES (%s, %s, %s, %s)",
        (user_id, test_uid, title, None),
    )
    conn.commit()
    cursor.close()
    conn.close()

    await state.update_data(test_uid=test_uid)
    await message.answer(get_translation(lang,"state_desc"))
    await state.set_state(QuizStates.DESCRIPTION)


# Tavsifni o'tkazib yuborish
@router.message(Command("skip"), QuizStates.DESCRIPTION)
async def skip_description(message: Message, state: FSMContext):
    user_id = message.chat.id
    lang = await get_user_language(user_id)
    await message.answer(get_translation(lang,"skip_desc"))

    await state.set_state(QuizStates.BANNER_VICTORY)


# Tavsif olish
@router.message(QuizStates.DESCRIPTION)
async def receive_description(message: Message, state: FSMContext):
    description = message.text
    data = await state.get_data()
    test_uid = data.get("test_uid")
    user_id = message.chat.id
    lang = await get_user_language(user_id)
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE tests SET description = %s WHERE test_uid = %s", (description, test_uid))
    conn.commit()
    cursor.close()
    conn.close()


    await message.answer(get_translation(lang,"state_banner"))
    await state.set_state(QuizStates.BANNER_VICTORY)

# Banner uchun rasmni qabul qilish
@router.message(F.content_type == types.ContentType.PHOTO,QuizStates.BANNER_VICTORY)
async def receive_banner(message: Message, state: FSMContext):
    # Rasmdan URL olish
    user_id = message.chat.id
    photo_id = message.photo[-1].file_id
    file = await message.bot.get_file(photo_id)
    file_url = f"https://api.telegram.org/file/bot{message.bot.token}/{file.file_path}"

    # Rasmni saqlash
    data = await state.get_data()
    test_uid = data.get("test_uid")
    lang = await get_user_language(user_id)
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE tests SET banner_url = %s WHERE test_uid = %s", (file_url, test_uid))
    conn.commit()
    cursor.close()
    conn.close()

    # Javob
    await message.answer(get_translation(lang,"state_prize"))
    await state.set_state(QuizStates.PRIZE)

@router.message(Command("skip"), QuizStates.PRIZE)
async def skip_description(message: Message, state: FSMContext):
    user_id = message.chat.id
    lang = await get_user_language(user_id)
    time_menu = create_time_menu_keyboard(lang)
    await message.answer(get_translation(lang,"state_time"),reply_markup=time_menu)

    await state.set_state(QuizStates.TIME_QUIZ)


@router.message(QuizStates.PRIZE)
async def receive_prize(message: Message, state: FSMContext):
    prize = message.text
    user_id = message.chat.id
    lang = await get_user_language(user_id)

    # Balansni tekshirish uchun foydalanuvchi ma'lumotini olish
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT balance FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()

    if user_data is None:
        await message.answer(get_translation(lang, "user_notfound"))
        cursor.close()
        conn.close()
        return

    user_balance = user_data[0]

    # Prize miqdorini tekshirish
    try:
        prize = float(prize)
        if prize > user_balance:
            shortage = prize - user_balance
            balance_message = get_translation(lang, "insufficient_balance_details").format(
                current_balance=user_balance, shortage=shortage
            )
            await message.answer(balance_message)
            cursor.close()
            conn.close()
            return
    except ValueError:
        await message.answer(get_translation(lang, "invalid_prize"))
        cursor.close()
        conn.close()
        return

    # Prize miqdorini saqlash
    data = await state.get_data()
    test_uid = data.get("test_uid")
    cursor.execute("UPDATE tests SET prize = %s WHERE test_uid = %s", (prize, test_uid))
    conn.commit()
    cursor.close()
    conn.close()

    # Keyingi davlatga o'tish
    time_menu = create_time_menu_keyboard(lang)
    await message.answer(get_translation(lang, "state_time"), reply_markup=time_menu)
    await state.set_state(QuizStates.TIME_QUIZ)



# Vaqt tugmalarini qayta ishlash
@router.callback_query(QuizStates.TIME_QUIZ)
async def handle_time_selection(callback: CallbackQuery, state: FSMContext):
    time_mapping = {
        "time:10": 10,
        "time:15": 15,
        "time:30": 30,
        "time:60": 60,
        "time:120": 120,
        "time:180": 180
    }
    user_id = callback.message.chat.id
    lang = await get_user_language(user_id)
    data = await state.get_data()
    test_uid = data.get("test_uid")
    selected_time = time_mapping.get(callback.data)

    if selected_time:
        # Vaqtni saqlash

        user_id = callback.message.chat.id
        lang = await get_user_language(user_id)
        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE tests SET time_quiz = %s WHERE test_uid = %s", (selected_time, test_uid))
        conn.commit()
        cursor.close()
        conn.close()

        # Endi Shuffle tugmalarini ko'rsatamiz
        shuffle_menu = create_shuffle_menu_keyboard(lang)
        await callback.message.answer(get_translation(lang,"quiz_shuffle"), reply_markup=shuffle_menu)
        await state.set_state(QuizStates.SHUFFLE)
    else:
        await callback.answer(get_translation(lang,"wrong_choice"))

# Shuffle (Aralashtirish) tugmalarini qayta ishlash
@router.callback_query(QuizStates.SHUFFLE)
async def handle_shuffle_selection(callback: CallbackQuery, state: FSMContext):
    shuffle_mapping = {
        "quiz_random": "quiz_random",
        "answer_random": "answer_random",
        "all_random": "all_random",
        "no_random": "no_random"
    }
    user_id = callback.message.chat.id
    lang = await get_user_language(user_id)
    data = await state.get_data()
    test_uid = data.get("test_uid")
    selected_shuffle = shuffle_mapping.get(callback.data)

    if selected_shuffle:
        # Aralashtirish parametrini saqlash


        # Random parametrlari
        if selected_shuffle == "quiz_random":
            random_question = 1  # True
            random_options = 0  # False
        elif selected_shuffle == "answer_random":
            random_question = 0  # False
            random_options = 1  # True
        elif selected_shuffle == "all_random":
            random_question = 1  # True
            random_options = 1  # True
        else:
            random_question = 0  # False
            random_options = 0  # False

        # SQLga saqlash
        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE tests 
            SET random_question = %s, random_options = %s 
            WHERE test_uid = %s
        """, (random_question, random_options, test_uid))
        conn.commit()
        cursor.close()
        conn.close()

        create_test_text = get_translation(lang,"add_question")
        create_test =  get_translation(lang,"quiz_create")
        builder = ReplyKeyboardBuilder()
        builder.row(types.KeyboardButton(
            text=create_test,
            request_poll=types.KeyboardButtonPollType(type="quiz"))
        )
        # Keyingi qadamga o'tish
        await callback.message.answer(create_test_text, reply_markup=builder.as_markup(resize_keyboard=True))
        await state.set_state(QuizStates.ADD_QUESTIONS)
    else:
        await callback.answer(get_translation(lang,"wrong_choice"))


@router.message(Command('done'), QuizStates.ADD_QUESTIONS)
async def test_complete(message: types.Message, state: FSMContext):
    user_id = message.chat.id
    lang = await get_user_language(user_id)

    # Ma'lumotlar bazasidan foydalanuvchi balansini olish va testning prize miqdorini olish
    conn = db_connection()
    cursor = conn.cursor()
    data = await state.get_data()
    test_uid = data.get("test_uid")

    # Prize va user balance ni olish
    cursor.execute("SELECT prize FROM tests WHERE test_uid = %s", (test_uid,))
    test_data = cursor.fetchone()

    if not test_data:
        await message.answer(get_translation(lang, "test_notfound"))
        cursor.close()
        conn.close()
        return

    prize = float(test_data[0])  # Prize qiymatini float turiga o'zgartirish

    cursor.execute("SELECT balance FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        await message.answer(get_translation(lang, "user_notfound"))
        cursor.close()
        conn.close()
        return

    user_balance = float(user_data[0])  # Balans qiymatini float turiga o'zgartirish

    # Balansni tekshirish
    if prize > user_balance:
        shortage = prize - user_balance
        balance_message = get_translation(lang, "insufficient_balance_details").format(
            current_balance=user_balance, shortage=shortage
        )
        top_up_button = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=get_translation(lang, "top_up_button"), callback_data="top_up")]
        ])
        await message.answer(balance_message, reply_markup=top_up_button)
        cursor.close()
        conn.close()
        return

    # Mablag'ni balansdan yechish
    new_balance = user_balance - prize
    cursor.execute("UPDATE users SET balance = %s WHERE user_id = %s", (new_balance, user_id))
    conn.commit()
    cursor.close()
    conn.close()

    # Foydalanuvchini asosiy menyuga qaytarish
    remove_keyboard = types.ReplyKeyboardRemove()
    await message.answer(get_translation(lang, "test_completed"), reply_markup=remove_keyboard)

    welcome_text = get_translation(lang, "welcome")
    keyboard = create_main_menu_keyboard(lang)
    await message.answer(welcome_text, reply_markup=keyboard)

    await state.set_state(QuizStates.HOME)

