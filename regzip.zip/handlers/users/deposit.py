from aiogram import Router, F, types
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from data.config import ADMINS
from db.db import get_user_currency, get_currency_card, db_connection, get_currency_name
from lang.translate import get_translation, get_user_language
from states.test import DepositStates

router = Router()


@router.callback_query(F.data == "deposit")
async def start_deposit(callback: types.CallbackQuery, state: FSMContext):
    """
    Foydalanuvchi "Deposit" tugmasini bosganda.
    """
    user_id = callback.from_user.id
    lang = await get_user_language(user_id)

    # Valyuta ID va nomini olish
    currency_id = await get_user_currency(user_id)
    currency_name = get_currency_name(currency_id)

    # Kartani olish
    card_number = get_currency_card(currency_name)

    if not card_number:
        await callback.message.answer(get_translation(lang, "no_card_info"))
        return

    await state.update_data(currency=currency_name, card=card_number)
    await callback.message.answer(
        f"{get_translation(lang, 'deposit_card_info')}: {card_number}\n"
        f"{get_translation(lang, 'enter_amount')}"
    )
    await state.set_state(DepositStates.enter_amount)


@router.message(StateFilter(DepositStates.enter_amount))
async def enter_amount(message: types.Message, state: FSMContext):
    """
    Foydalanuvchi summani yuborganda.
    """
    userid = message.from_user.id
    lang = await get_user_language(userid)

    if not message.text.isdigit():
        await message.answer(get_translation(lang,"wrong_money"))
        return

    amount = int(message.text)
    await state.update_data(amount=amount)
    await message.answer(get_translation(lang,"send_screen"))
    await state.set_state(DepositStates.wait_receipt)


@router.message(StateFilter(DepositStates.wait_receipt), F.photo)
async def receive_receipt(message: types.Message, state: FSMContext):
    """
    Foydalanuvchidan chekning rasmini olish va adminlarga yuborish.
    """
    data = await state.get_data()
    userid = message.from_user.id
    lang = await get_user_language(userid)

    currency = data['currency']  # Foydalanuvchining valyutasi
    amount = data['amount']  # Foydalanuvchi yuborgan miqdor

    # Admin uchun ma'lumot
    admin_message = (
        f"📥 Yangi depozit so'rovi:\n"
        f"👤 Foydalanuvchi: {message.from_user.full_name}\n"
        f"💰 Valyuta: {currency}\n"
        f"💵 Miqdor: {amount}\n\n"
        f"✅ Chek rasmini ko'rib chiqing va tasdiqlang."
    )

    # Tasdiqlash tugmasi: user_id, amount va valyutani qo'shish
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Tasdiqlash",
                    callback_data=f"confirm_deposit_{message.from_user.id}_{amount}_{currency}"
                )
            ]
        ]
    )
    await message.answer(get_translation(lang,"succes_send_screen"))
    # Adminga xabar yuborish
    for admin_id in ADMINS:  # Admin ID-lari ro'yxati
        await message.bot.send_photo(
            chat_id=admin_id,
            photo=message.photo[-1].file_id,
            caption=admin_message,
            reply_markup=keyboard
        )


    await state.clear()


@router.callback_query(F.data.startswith("confirm_deposit"))
async def confirm_deposit(callback: types.CallbackQuery):
    """
    Admin depozitni tasdiqlaganda.
    """
    userid = callback.from_user.id
    lang = await get_user_language(userid)

    try:
        print(callback.data)  # Debug uchun

        # Callback_data'ni ajratamiz
        data = callback.data.split("_")

        # Ma'lumotlar: user_id, amount va currency
        if len(data) < 5:
            await callback.answer("Xatolik: Noto'g'ri ma'lumot formati!")
            print(f"Error: Malformed callback data - {callback.data}")
            return

        user_id = int(data[2])  # User ID
        amount = float(data[3])  # Depozit miqdori
        currency = data[4]  # Valyuta

        # Valyuta kursini olish (Admin jadvalidan)
        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT rate FROM admin WHERE currency_name = %s", (currency,))
        result = cursor.fetchone()

        if not result:
            await callback.answer(f"Xatolik: {currency} valyuta kursi topilmadi!")
            return

        rate = result[0]  # Valyuta kursi
        tanga_miqdori = amount / rate  # Tangaga hisoblash
        print(f"{amount} {currency} = {tanga_miqdori} tanga (kurs: {rate})")

        # Foydalanuvchi balansini yangilash
        cursor.execute("UPDATE users SET balance = balance + %s WHERE user_id = %s", (tanga_miqdori, user_id))
        conn.commit()

        # Ulashmalarni yopish
        cursor.close()
        conn.close()
        succes_pay = get_translation(lang, "succes_pay").format(
            tanga_miqdori=tanga_miqdori
        )
        # Foydalanuvchiga xabar yuborish
        await callback.message.bot.send_message(
            chat_id=user_id,
            text=succes_pay
        )

        # Admin uchun xabarni o'zgartirish
        await callback.message.edit_caption("✅ Depozit muvaffaqiyatli tasdiqlandi.")
    except Exception as e:
        print(f"Xatolik: {e}")
        await callback.answer("Xatolik yuz berdi, iltimos tekshiring.")
