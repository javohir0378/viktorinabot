import datetime
import random

from aiogram import types, F, Router
from aiogram.enums import PollType
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, PollAnswer

from app import dp, bot

router = Router()


from aiogram import types
from aiogram.fsm.context import FSMContext
from db.db import db_connection, send_question, check_and_start_test, check_random_question, send_results


from collections import defaultdict

# Guruhda testga qo'shilgan foydalanuvchilarni kuzatish uchun lug'at
group_participants = defaultdict(set)

@router.callback_query(F.data.startswith("start_quiz:"))
async def start_quiz(callback: types.CallbackQuery, state: FSMContext):
    chat_id = callback.message.chat.id
    user_id = callback.from_user.id
    test_uid = callback.data.split(":")[1]

    # Guruh emasligini tekshirish
    #if callback.message.chat.type not in ["group", "supergroup"]:
     #   await callback.message.answer("Test faqat guruhda boshlanadi.")
    #    return

    # Guruhdagi foydalanuvchini ro‘yxatga qo‘shish
  #  group_participants[chat_id].add(user_id)

    ##if len(group_participants[chat_id]) < 2:
     #   await callback.message.answer(
      #      f"Testni boshlash uchun kamida 2 kishi kerak. Hozircha {len(group_participants[chat_id])} kishi tugmani bosdi."
      #  )
     #   return

    connection = None
    try:
        connection = db_connection()
        if not connection:
            await callback.message.answer("Xatolik: Baza bilan bog'lanishda muammo yuz berdi.")
            return

        cursor = connection.cursor()

        query = "SELECT question_id FROM questions WHERE test_uid = %s"
        cursor.execute(query, (test_uid,))
        all_questions = [row[0] for row in cursor.fetchall()]

        if not all_questions:
            await callback.message.answer("Test uchun savollar topilmadi.")
            return

        # Pollsda yuborilgan savollarni aniqlash
        query = "SELECT question_id FROM polls WHERE user_id = %s AND test_uid = %s"
        cursor.execute(query, (user_id, test_uid))
        sent_questions = [row[0] for row in cursor.fetchall()]

        # Qolgan savollarni aniqlash
        remaining_questions = list(set(all_questions) - set(sent_questions))
        if not remaining_questions:
            await callback.message.answer("Test avval yakunlangan.")
            await send_results(user_id, test_uid)
            return

        # Random yoki birinchi savolni tanlash
        random_question = await check_random_question(test_uid)
        question_id = random.choice(remaining_questions) if random_question else min(remaining_questions)

        await send_question(callback.message.chat.id, test_uid, question_id)

    except Exception as e:
        print(f"Xato: {e}")
        await callback.message.answer("Xatolik yuz berdi. Keyinroq urinib ko'ring.")
    finally:
        if connection:
            connection.close()