from aiogram.types import Message

from db.db import db_connection
from keyboards.reply.keyboards import create_balance_keyboard
from lang.translate import get_translation, get_user_language


async def get_coin_balance(user_id: int):
    """
    Foydalanuvchining tangalar balansini va tanlangan valyutadagi qiymatini hisoblash.
    :param user_id: Telegram foydalanuvchisi ID
    :return: (coin_balance, calculated_balance, currency_name)
    """
    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchining balans va valyutasini olish
    cursor.execute("SELECT balance, currency FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        cursor.close()
        conn.close()
        return None, None, None

    coin_balance, currency = user_data

    # Valyuta bo'yicha narxni olish
    currency_map = {1: "UZS", 2: "RUB", 3: "USD"}
    cursor.execute("SELECT rate FROM admin WHERE currency_name = %s", (currency_map[currency],))
    rate_data = cursor.fetchone()

    cursor.close()
    conn.close()

    if not rate_data:
        return coin_balance, None, None

    rate = rate_data[0]
    calculated_balance = coin_balance * rate
    return coin_balance, calculated_balance, currency_map[currency]

async def send_balance_message(user_id: int, lang: int, message: Message):
    """
    Foydalanuvchiga balansni va hisoblangan qiymatni ko'rsatish.
    """
    coin_balance, calculated_balance, currency_name = await get_coin_balance(user_id)

    if coin_balance is None:
        await message.answer(get_translation(lang, "user_notfound"))
        return

    # Xabar matni
    balance_message = (
        f"💰 {get_translation(lang, 'your_balance')}: {coin_balance} {get_translation(lang, 'coins')}\n"
        f"💱 {get_translation(lang, 'balance_value')}: {calculated_balance:.2f} {currency_name}\n\n"
        f"{get_translation(lang, 'choose_action')}"
    )

    # Tugmalar bilan jo'natish
    keyboard = create_balance_keyboard(lang)
    await message.answer(balance_message, reply_markup=keyboard)

async def get_user_coin_balance_and_value(user_id: int):
    """
    Foydalanuvchining balansidagi tangalar va hisoblangan valyutadagi qiymatini olish.
    """
    conn = db_connection()
    cursor = conn.cursor()

    # Foydalanuvchi balansini va valyutasini olish
    cursor.execute("SELECT balance, currency FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        cursor.close()
        conn.close()
        return None, None, None

    coin_balance, currency = user_data

    # Valyuta kursini olish
    currency_map = {1: "UZS", 2: "RUB", 3: "USD"}
    cursor.execute("SELECT rate FROM admin WHERE currency_name = %s", (currency_map[currency],))
    rate_data = cursor.fetchone()

    cursor.close()
    conn.close()

    if not rate_data:
        return coin_balance, None, None

    rate = rate_data[0]
    calculated_balance = coin_balance * rate
    return coin_balance, calculated_balance, currency_map[currency]



async def handle_balance(user_id: int,message:Message):

    user_id = user_id
    lang = await get_user_language(user_id)  # Foydalanuvchining tilini olish
    coin_balance, calculated_value, currency = await get_user_coin_balance_and_value(user_id)

    if coin_balance is None:
        await message.answer(get_translation(lang, "user_notfound"))
        return

    # Balans xabari
    balance_message = (
        f"💰 {get_translation(lang, 'your_balance')}: {coin_balance} {get_translation(lang, 'coins')}\n"
        f"💱 {get_translation(lang, 'balance_value')}: {calculated_value:.2f} {currency}\n\n"
        f"{get_translation(lang, 'choose_action')}"
    )

    balance_menu = create_balance_keyboard(lang)  # Asosiy menyu tugmalari
    await message.answer(balance_message, reply_markup=balance_menu)


